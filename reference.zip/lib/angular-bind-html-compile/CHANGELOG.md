### 1.4.1

* Fix issue with `module` being `undefined` when using outside bundlers

## 1.4.0

* Add possibility to install with `npm`

### 1.2.1

* Change strict angular dependency to `~1.x`

## 1.2.0

* Add a minified version of the library

## 1.1.0

* Allow a specific scope to be passed in to the directive using `bind-html-scope`
* Add grunt code style tests and release notes

### 1.0.2

* BUGFIX: ensure element.html() always gets an HTML string if given the result of a $sce method, a TrustedValueHolderType.

### 1.0.1

* Add AngularJS dependency.

# 1.0.0

* Initial release.
