'use strict';

app.controller('ComposerCtrl', ['$scope', '$compile', '$uibModal','readFilePreview','metadataapiAPIservice', 
	function($scope, $compile, $uibModal,readFilePreview,metadataapiAPIservice) {

	$scope.widgets = Widgets;
	$scope.current = null;
//	$scope.allTenant = [];
//	metadataapiAPIservice.loadTenants().then(
//		function(result){
//			if(result && result!=null){
//				try{
//					var tenantItems = result.data.facetCount.facetFields.tenantCode.facetItems;
//					angular.forEach(tenantItems, function(count, tenantcode) {
//						if(count>0)
//							$scope.allTenant.push(tenantcode);
//					});
//					$scope.allTenant.sort();
//				}
//				catch(err){
//					console.warn("loadTenants error" , err);
//				} 			
//			}
//		},
//		function(result){
//			console.error("loadTenants error", result);
//		}
//	);
	
	$scope.dashboard = {"name": "New Dashboard", "components": new Array()};

	// LaReteDistri_3267
	// StudentiPiem_2096
	// PosizioneGiu_2088
	// StudentiStra_2089

//	$scope.htmlelements = [
//			{
//				key: 'text',	
//				name: 'html_text',
//				html: function(){return '<div class="yucca-html_text">' + this.params.content.values + '</div>';},
//				params: {'content': {'name':'content','multiple': 'false', 'key_value': 'false','mandatory':'false','values':'Text', 'default':'','custom':''}},
//				advancedParams: {},
//				styles: {'yucca-html_text':{'name':'yucca-html_text','desc':'yucca-html_text','custom':''}}
//			},{
//				key: 'image',	
//				name: 'html_image',
//				html: function(){return '<img src="' + this.params.imageurl.values + '" />';},
//				params: {'imageurl': {'name':'imageurl','multiple': 'false', 'key_value': 'false','mandatory':'false','values':'/images/img-placeholder.png', 'default':'','custom':''}},
//				advancedParams: {},
//				styles: {'yucca-html_text':{'name':'yucca-html_text','desc':'yucca-html_text','custom':''}}
//			}
//		];
	
	$scope.dragdrop = {isDragging:false};

	var componentCounter = 0;
	$scope.onDropComponent = function($data,$event){
		console.debug("onDropComponent",$data,$event);
		if($scope.dragdrop.isDragging){
			if(typeof $data == 'undefined' || $data == null|| typeof $data.componentId == 'undefined'){ // new component
				var component_type = $data.name.split("_")[0];
				console.log("component_type",component_type)
				var newComponent = {"componentId": "component_"+componentCounter, "type": "yucca-"+component_type,
						"style": {},
						"content": angular.copy($data), 
						"styles": new Array()};
				$scope.dashboard.components.push(newComponent);
				$scope.current = newComponent;
				$scope.editComponentConfig(newComponent);
				componentCounter++;
			}
			$scope.dragdrop.isDragging=false;
		}
	};
	
	$scope.accordions = {"widget": {"basic":true}, "htmlelement": false, "params": {"mandatory_params":true}, "events": {"event_listening":true, "event_sending": true}, "export": false};
	
	$scope.onMoveDropComplete = function (index, obj, evt) {
        var otherObj = $scope.dashboard.components[index];
        var otherIndex = $scope.dashboard.components.indexOf(obj);
        $scope.dashboard.components[index] = obj;
        $scope.dashboard.components[otherIndex] = otherObj;
		if($scope.isResizing)
			$scope.isResizing = false;
    }
	
	var currentResizeStart = {w:0,h:0, x:0, y:0};
	
	$scope.isResizing=false;
	
	$scope.onStartResizeComponent = function($data,$event, type){
		currentResizeStart.type = type;
		currentResizeStart.w=document.getElementById($data.componentId).clientWidth;
		currentResizeStart.h=document.getElementById($data.componentId).clientHeight;
		currentResizeStart.x=$event.x;
		currentResizeStart.y=$event.y; 
		$scope.isResizing = true;
	};
	
	$scope.onFinishResizeComponent = function(){
		$scope.isResizing = false;
	}
	$scope.onResizeComponent = function($data,$event){
		if($scope.isResizing){
			var newWidth = currentResizeStart.w + ($event.x - currentResizeStart.x)
			var newHeight = currentResizeStart.h + ($event.y - currentResizeStart.y)
	//		var newX = $event.x;
	//		var newY = $event.y;
			if(currentResizeStart.type == "width" || currentResizeStart.type == "both" )
				$data.content.params.common.chart_width.values = newWidth;
			if(currentResizeStart.type == "height" || currentResizeStart.type == "both" )
				$data.content.params.common.chart_height.values = newHeight;
		}
		return false;
	  	
	};
	
	$scope.resetSizeComponent  = function (c){
		delete c.style.width;
		delete c.style.height;
	};
	
	$scope.isComponentReady = function(c){
		var isReady  = true;
		if(c && c.content && c.content.params){
			for (var paramSectionKey in c.content.params) {
			    if (c.content.params.hasOwnProperty(paramSectionKey)) {
			    	var paramSection = c.content.params[paramSectionKey];
					for (var paramKey in paramSection) {
					    if (paramSection.hasOwnProperty(paramKey)) {
			    	
					    	var v = paramSection[paramKey].values;
					    	
					    	if(paramSection[paramKey].mandatory == "true" && (v == null || v.length==0)){
					    		isReady  = false;
					    		break;
					    	}
					    }
					}
			    }
			}
			
		}
		return isReady;
	}
	
	$scope.removeComponent = function(componentIndex){
		$scope.dashboard.components.splice(componentIndex,1);
		$scope.current = null;

	};
	
	$scope.getStyle  =function(c){
		var out ="";
		if(Utils.has(c, 'content.params.common.chart_width.values') && c.content.params.common.chart_width.values
				&& c.content.params.common.chart_width.values!=null && c.content.params.common.chart_width.values!="")
			out+= "width:"  + c.content.params.common.chart_width.values +"px;";
		if(Utils.has(c, 'content.params.common.chart_height.values') && c.content.params.common.chart_height.values 
				&& c.content.params.common.chart_height.values!=null && c.content.params.common.chart_height.values!="")
			out+= "height:"  + c.content.params.common.chart_height.values +"px;";
		return out;
	};
	
	$scope.debug  = function(){
		console.log("current", $scope.current);
		console.log("components", $scope.dashboard.components);
	};
	
	$scope.showWidgetCode = function(c){
		var widgetCodeRaw = $scope.getHtmlContent(c);
		var widgetCode = Utils.render.prettifyHtml(widgetCodeRaw);
		var widgetStyleRaw = $scope.getCssContent(c);
		var widgetStyle = Utils.render.prettifyCss(widgetStyleRaw);
		console.log("showWidgetCode", widgetCode);
		$uibModal.open({
			animation: true,
		    templateUrl: 'WidgetCodeDialog.html',
		    controller: 'WidgetCodeDialogCtrl',
		    resolve: {
		    	widgetCode: function () {return widgetCode;},
		    	widgetCodeRaw: function(){return widgetCodeRaw},
				widgetStyle: function () {return widgetStyle;},
		    	widgetStyleRaw: function(){return widgetStyleRaw}
		    }
		});

	};
	
	
//	var prettifyHtml = function(code){
//		var prettycodeTokens = code.replace("<","&lt;").replace("/>","").replace(/\s\s+/g, ' ').split(' ');
//		prettycodeTokens[0] = "<span class='tag'>"+prettycodeTokens[0] +"</span><br>"
//		for (var i = 1; i < prettycodeTokens.length; i++) {
//			prettycodeTokens[i] = "&nbsp;&nbsp;<span class='atn'>"+prettycodeTokens[i].replace("=","</span>=<span class='pun'>") + "</span><br>";
//		}
//		
//		prettycodeTokens.push("<span class='tag'>/&gt;</span>");
//		return prettycodeTokens.join(" ");
//		
//	}
	
	$scope.getHtmlContent = function(c){
		return Utils.widget.getWidgetCodeRaw(c);
//		var out = "";
//		if(c && (c.type=='yucca-widget' || c.type=='yucca-control')){
//			out += "<"+c.content.directive;
//			angular.forEach(c.content.params, function(param_section, param_section_key){
//				angular.forEach(param_section, function(p, p_key){
//			    	if(p.values != null && p.values !="")
//			    		out += " " +p.name + "='"+p.values+"'"; 
//			    });
//			});
//			angular.forEach(c.content.events, function(event_section, event_section_key){
//				angular.forEach(event_section, function(e, e_key){
//			    	if(e.values != null && e.values !="")
//			    		out += " " +e.name + "='"+e.values+"'"; 
//			    });
//			});
////			for (var property in c.content.advancedParams) {
////			    if (c.content.advancedParams.hasOwnProperty(property)) {
////			    	var p = c.content.advancedParams[property];
////			    	if(p.values != null && p.values !="")
////			    		out += " " +p.name + "='"+p.values+"'"; 
////			    }
////			}
//			out += "/>";
//			
//		}
//		else if(c && c.type=='yucca-html'){
//			out = c.content.html();
//		}
//		return out;
	};
	
//	var prettifyCss = function(code){
//		var out = "";
//		if(code){
//			var rows = code.split("\n");
//			for (var i = 0; i < rows.length; i++) {
//				if(rows[i]!=""){
//					var selector = rows[i].split("{")[0];
//					var rules = rows[i].split("{")[1].replace("}","");
//					out += "<div><span class='slc'>"+selector+"</span>{" +  Utils.prettifyCss(rules) + "}</div>";
//				}
//			}
//		}
//		return out;
//		
//	}
	
	$scope.getCssContent = function(c){
		return Utils.widget.getWidgetCssRaw(c);
//		var out = "";
//		if(c && c.type=='yucca-widget'){
//			angular.forEach(c.content.styles, function(style_section, style_section_key){
//				angular.forEach(style_section, function(s, s_key){
//			    	if(s.custom != null && s.custom !="")
//			    		out += ".yucca-widget " +s.selector+ "{"+s.custom+"}\n";
//			    	
//			    });
//			});
//		}
//		else if(c && c.type=='yucca-html'){
//			out = c.content.html();
//		}
//		return out;
	};
	
	var getParamValue = function(c,p){
		return null;
	};
	
	$scope.editDashboardTitle = function(startEdit){
		console.log("editDashboardTitle", startEdit);
		$scope.isEditingTitle = startEdit;
	}
	
	$scope.saveDashboard = function(){
	    var json = new Blob([JSON.stringify($scope.dashboard)], {type: "text/json"});
	    var  downloadLink = document.createElement("a");
	    downloadLink.download = $scope.dashboard.name + ".json";
	    downloadLink.href = window.URL.createObjectURL(json);
	    downloadLink.style.display = "none";
	    document.body.appendChild(downloadLink);
	    downloadLink.click();
		document.body.removeChild(downloadLink);
	};
	
	var checkComponentsId = function(){
		var max=0;
		var ids = new Array();
		for (var i = 0; i < $scope.dashboard.components.length; i++) {
			ids.push(parseInt($scope.dashboard.components[i].componentId.replace("component_","")));
		}
		
		var sorted_ids = ids.slice().sort(); 
		var foundDuplicate = false;
		for (var i = 0; i < sorted_ids.length - 1; i++) {
			if (sorted_ids[i + 1] == sorted_ids[i]) {
				foundDuplicate = true;
				break;
			}
		}
		if(foundDuplicate){
			for (var i = 0; i < $scope.dashboard.components.length; i++) {
				$scope.dashboard.components[i].componentId = "component_"+componentCounter;
				componentCounter++;
			}
		}
		else
			componentCounter = sorted_ids[sorted_ids.length-1]  +1;

	};
	
	$scope.loadDashboard = function($file){
		console.log("loadDashboard",$file);
		readFilePreview.readTextFile($file[0], 100000, 'UTF-8').then(function(contents){
			console.log("loadDashboard content", contents);
			$scope.dashboard = JSON.parse(contents);
			console.log("$scope.dashboard", $scope.dashboard);
			checkComponentsId();
			
		}).then(function(error){
			console.error("loadDashboard error", error);
		})

		
	};
	

	
	
	$scope.downloadProject = function(){
		var promise = new JSZip.external.Promise(function (resolve, reject) {
		    JSZipUtils.getBinaryContent('/template/embedProject.zip', function(err, data) {
		        if (err) {
		            reject(err);
		        } else {
		        	console.log("resolve");
		            resolve(data);
		        }
		    });
		});
		
		var embedProjectZip;
		promise.then(JSZip.loadAsync)                     // 2) chain with the zip promise
		.then(function(zip) {
			 embedProjectZip = zip;
			 return embedProjectZip.file("dashboard.html").async("string");
		}).then(function success(html) {     
			console.log("html");
			html = html.replace("##DASHBOARD_HTML##", exportDashboardHtml());
			embedProjectZip.file("dashboard.html",html);
			return embedProjectZip.file("css/yucca-dashboard.css").async("string");
		}).then(function success(css) {     
			console.log("css");
			css = css.replace("##DASHBOARD_CSS##", exportDashboardCss());
			embedProjectZip.file("css/yucca-dashboard.css",css);
			return embedProjectZip.file("js/yucca-dashboard.js").async("string");
		}).then(function success(js) {   
			console.log("js");
			js = js.replace("##DASHBOARD_JS##", exportDashboardJs());
			embedProjectZip.file("js/yucca-dashboard.js",js);
			embedProjectZip.generateAsync({type:"blob"})
			.then(function(content) {
			   var downloadLink = document.createElement("a");
			    downloadLink.download = $scope.dashboard.name + ".zip";
			    downloadLink.href = window.URL.createObjectURL(content);
			    downloadLink.style.display = "none";
			    document.body.appendChild(downloadLink);
			    downloadLink.click();
				document.body.removeChild(downloadLink);
			});
		});
		
		
		
//		var zip = new JSZip();
//		zip.file("Hello.txt", "Hello World\n");
//		var img = zip.folder("images");
//		img.file("smile.gif", imgData, {base64: true});
//		zip.generateAsync({type:"blob"})
//		.then(function(content) {
//		    // see FileSaver.js
//		    saveAs(content, "example.zip");
//		});
	};
	
	
	
	var exportDashboardHtml = function(){
		
		var out="";
		for (var i = 0; i < $scope.dashboard.components.length; i++) {
			var  c = $scope.dashboard.components[i];
			out +=  '<div class="yucca-dashboard-component-card" id="'+c.componentId+'">\n';
			out += '    <'+c.content.directive + ' ';
			if(typeof c.content.params != 'undefined' && c.content.params!=null){
				for (var property in c.content.params) {
				    if (c.content.params.hasOwnProperty(property) ) {
						var p = c.content.params[property];
						console.log("p",p);
						if(p.values != ""){
							out += p.name + ' ="{{'+ c.componentId + '.' + p.name + '}}" ';
						}
				    }
				}
			}
			if(typeof c.content.advancedParams != 'undefined' && c.content.advancedParams!=null){
				for (var property in c.content.advancedParams) {
				    if (c.content.advancedParams.hasOwnProperty(property) ) {
						var p = c.content.advancedParams[property];
						console.log("p",p);
						if(p.values != ""){
							out += p.name + ' ="{{'+ c.componentId + '.' + p.name + '}}" ';
						}
				    }
				}
			}
			out += ' />\n';
			out += '</div>\n';
		}
		
		return out;
		
	};
	
	var exportDashboardCss = function(){
		var out="";
		
		for (var i = 0; i < $scope.dashboard.components.length; i++) {
			var cardStyle = '';
			var  c = $scope.dashboard.components[i];
			for (var property in c.style) {
				if (c.style.hasOwnProperty(property)) {
					cardStyle += property + ': ' + c.style[property] + ';'
				}
			}
			if(cardStyle != '')
				out += '#'+c.componentId + '{' + cardStyle + '}\n\n';
			
			for (var property in c.content.styles) {
				if (c.content.styles.hasOwnProperty(property) && c.content.styles[property].custom!="") {
					out += '#'+c.componentId + ' .' + property + '{' + c.content.styles[property].custom + '}\n';
				}
			}
		}
		
		
		
		
		return out;
	};
	
	var exportDashboardJs = function(){
		var out="";
		out += "  $scope.dashboardTitle = '" + $scope.dashboard.name + "';\n";
		for (var i = 0; i < $scope.dashboard.components.length; i++) {
			var  c = $scope.dashboard.components[i];
			out += '  $scope.' + c.componentId + ' = {};\n'
			if(typeof c.content.params != 'undefined' && c.content.params!=null){
				for (var property in c.content.params) {
				    if (c.content.params.hasOwnProperty(property) ) {
						var p = c.content.params[property];
						console.log("p",p);
						if(p.values != ""){
							if(p.multiple == "true")
								out += '  $scope.' + c.componentId + '.' + p.name + ' =' + p.values + ';\n';
							else
								out += '  $scope.' + c.componentId + '.' + p.name + ' ="' + p.values + '";\n';
						}
				    }
				}
			}
			
			if(typeof c.content.advancedParams != 'undefined' && c.content.advancedParams!=null){
				for (var property in c.content.advancedParams) {
				    if (c.content.advancedParams.hasOwnProperty(property) ) {
						var p = c.content.advancedParams[property];
						console.log("p",p);
						if(p.values != ""){
							if(p.multiple == "true")
								out += '  $scope.' + c.componentId + '.' + p.name + ' =' + p.values + ';\n';
							else
								out += '  $scope.' + c.componentId + '.' + p.name + ' ="' + p.values + '";\n';
						}
				    }
				}
			}
			
		}

		return out;
	};

	$scope.editComponentConfig = function(c){
		console.log("editComponentConfig", c, $scope.current);
		if(typeof c != 'undefined')
			$scope.current = c;
		
		if($scope.current){
			$scope.isEditingComponentConfig = true;
			$scope.isEditingComponentEvent = false;
			$scope.isEditingComponentStyle = false;
		}
	};
	
	$scope.editComponentEvent = function(c){
		console.log("editComponentEvent", c, $scope.current);
		if(typeof c != 'undefined')
			$scope.current = c;
		
		if($scope.current){
			$scope.isEditingComponentConfig = false;
			$scope.isEditingComponentEvent = true;
			$scope.isEditingComponentStyle = false;
		}
	};

	$scope.editComponentStyle = function(c){
		console.log("editComponentConfig", c);
		if(typeof c != 'undefined')
			$scope.current = c;
		
		if($scope.current){
			$scope.isEditingComponentConfig = false;
			$scope.isEditingComponentEvent = false;
			$scope.isEditingComponentStyle = true;
		}
	};

	$scope.openMultipleParamDialog = function(p){
		console.log("openMultipleParamDialog", p);
		var openMultipleParamDialogInstance = $uibModal.open({
			animation: true,
		    templateUrl: 'partials/modal/MultipleParamDialog.html',
		    controller: 'MultipleParamDialogInstanceCtrl',
		    resolve: {
		    	p: function () {return p;}
		    }
		});
		
		openMultipleParamDialogInstance.result.then(function (res) {
			console.log("result",res);
		}, function () {
			console.log('Modal dismissed at: ' + new Date());
		});
	};
	

	$scope.prettifyCss = Utils.prettifyCss;
	$scope.changedParams = false;
	
	$scope.currentmillis = new Date().getTime();

	
	$scope.changeParamEvent = function(){
		$scope.changedParams = true;
	};
	
	$scope.refreshPreview = function(widgetKey){
		var changedDirectiveUrl = Widgets[widgetKey].directiveUrl+'?t='+new Date().getTime();
		Widgets[widgetKey].directiveUrl = changedDirectiveUrl;
		$scope.changedParams = false;
	}; 

	$scope.changedStyle = "";
	$scope.openChangeStyleDialog = function(widgetKey, styleSection, styleName){
		console.log(widgetKey, styleName);
		var modalInstance = $uibModal.open({
			animation: true,
		    templateUrl: 'partials/modal/ChangeStyleDialog.html',
		    controller: 'ChangeStyleDialogInstanceCtrl',
		    resolve: {
		    	widgetKey: function () {return widgetKey;},
		    	styleSection: function () {return styleSection;},
		    	styleName: function () {return styleName;},
		    	existingRules: function(){return $scope.current.content.styles[styleSection][styleName].custom;}
		    }
		});
		
		modalInstance.result.then(function (res) {
			console.log("result",res,  $scope.current);
		    $scope.current.content.styles[res.styleSection][res.styleName].custom = res.rule;
		}, function () {
			console.log('Modal dismissed at: ' + new Date());
		});
	};

	
}]);


app.controller('WidgetCodeDialogCtrl', function ($scope, $uibModalInstance,widgetCode,widgetCodeRaw,widgetStyle, widgetStyleRaw, $timeout) {
	$scope.widgetCode = widgetCode;
	$scope.widgetCodeRaw = widgetCodeRaw;
	$scope.widgetStyle = widgetStyle;
	$scope.widgetStyleRaw = widgetStyleRaw;

	
	$scope.copyToClipboard = function(value){
	    console.log("copyToClipboard", value);
	    
	    var copyElement = document.createElement("span");
	    copyElement.appendChild(document.createTextNode(value));
	    copyElement.id = 'tempCopyToClipboard';
	    angular.element(document.body.append(copyElement));
	    
	    var range = document.createRange();
	    range.selectNode(copyElement);
	    window.getSelection().removeAllRanges();
	    window.getSelection().addRange(range);

	    // copy & cleanup
	    document.execCommand('copy');
	    window.getSelection().removeAllRanges();
        document.execCommand("copy");
        $scope.copyToClipboardFeedback = "copy_to_clipboard_feedback_ok";
        $timeout(function(){$scope.copyToClipboardFeedback = "";}, 1200);
        
        console.log("copied");
	};
	
	$scope.ok = function () {
	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});

app.controller('MultipleParamDialogInstanceCtrl', function ($scope, $uibModalInstance,p) {
	console.log("p" ,p);	 
	$scope.p = p;
	if(typeof $scope.p.values == 'undefined' || $scope.p.values == null  || $scope.p.values.length<1)
		$scope.newValues =new Array();
	else{
		$scope.newValues = JSON.parse($scope.p.values);
		//$scope.newValues = $scope.p.values.replace("[","").replace("]","").replace(/"/g, "").split(",");
	}
	$scope.addValue = function(value){
		$scope.newValues.push(value);
		$scope.newValue = null;
	};
	
	$scope.removeValue = function(valueIndex){
		if(typeof $scope.p.values!='undefined' && $scope.p.values!=null)
			$scope.newValues.splice(valueIndex,1);
	};
	
	$scope.ok = function () {
		//$scope.p.values = '["'+$scope.newValues.join('\",\"')+'"]';
		$scope.p.values = JSON.stringify($scope.newValues);

	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});

app.controller('GeojsonsDialogInstanceCtrl', function ($scope, $uibModalInstance,p) {
	console.log("p" ,p);	 
	$scope.p = p;
	if(typeof $scope.p.values == 'undefined' || $scope.p.values == null  || $scope.p.values.length<1)
		$scope.newValues =new Array();
	else{
		$scope.newValues = JSON.parse($scope.p.values);
		//$scope.newValues = $scope.p.values.replace("[","").replace("]","").replace(/"/g, "").split(",");
	}
	$scope.addGeojson = function(geojson){
		$scope.newValues.push(geojson);
		$scope.newGeojson = null;
	};
	
	$scope.removeGeojson = function(valueIndex){
		if(typeof $scope.p.values!='undefined' && $scope.p.values!=null)
			$scope.newValues.splice(valueIndex,1);
	};
	
	$scope.ok = function () {
		//$scope.p.values = '["'+$scope.newValues.join('\",\"')+'"]';
		$scope.p.values = JSON.stringify($scope.newValues);

	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});



app.controller('LegendParamDialogInstanceCtrl', function ($scope, $uibModalInstance,p, type) {
	console.log("p" ,p, type);	 
	$scope.p = p;
	$scope.type = type;
	
	$scope.updateVisibility = function(){	
		if(!$scope.show)
			$scope.position = {};
		else{
			if(type=='chart')
				$scope.position = {top: 12, right: -1, bottom: -1, left: 12};
			else
				$scope.position = 'topleft';
			$scope.updatePosition();
		}
	};
	
	
	$scope.presetPosition = function(top,right,bottom,left,mapposition){
		if($scope.show){
			if(type=='chart'){
				$scope.position.top = top;
				$scope.position.right = right;
				$scope.position.bottom = bottom;
				$scope.position.left = left;
				$scope.updatePosition();
			}
			else{
				$scope.position = mapposition;
				$scope.previewPosition = "";
				if(mapposition=='topleft')
					$scope.previewPosition += "top: 24px; left: 24px";
				else if(mapposition=='topright')
					$scope.previewPosition += "top: 24px; right: 24px";
				else if(mapposition=='bottomleft')
					$scope.previewPosition += "bottom: 24px; left: 24px";
				else if(mapposition=='bottomright')
					$scope.previewPosition += "bottom: 24px; right: 24px";
				
			}
		}
	}
	
	$scope.updatePosition = function(){
		$scope.previewPosition = "";
		if($scope.position.top>0)
			$scope.previewPosition += "top: " + $scope.position.top*2 + "px; ";
		if($scope.position.right>0)
			$scope.previewPosition += "right: " + $scope.position.right*2 + "px; ";
		if($scope.position.bottom>0)
			$scope.previewPosition += "bottom: " + $scope.position.bottom*2 + "px; ";
		if($scope.position.left>0)
			$scope.previewPosition += "left: " + $scope.position.left*2 + "px; ";
	};
	
	if(typeof $scope.p.values == 'undefined' || $scope.p.values == null  || $scope.p.values == ""){
		$scope.show = false;
		$scope.position = {};
	}
	else{
		var parsed = JSON.parse($scope.p.values);
		$scope.show = parsed.show;
		$scope.position = parsed.position;		
		$scope.updatePosition();

	}
	
	$scope.ok = function () {
		var result = {show: $scope.show, position: {}};
		if($scope.show){
			if(type=='chart'){
				if($scope.position.top>0)
					result.position.top = $scope.position.top
				if($scope.position.right>0)
					result.position.right = $scope.position.right;
				if($scope.position.bottom>0)
					result.position.bottom = $scope.position.bottom;
				if($scope.position.left>0)
					result.position.left = $scope.position.left;
			}
			else
				result.position = $scope.position;
		}
		$scope.p.values = JSON.stringify(result);
	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});


app.controller('PiechartrenderDialogInstanceCtrl', function ($scope, $uibModalInstance,$timeout, p) {
	console.log("p" ,p);	 
	$scope.p = p;
	$scope.piechartrender = {a:1, r:0};
	
	// cornerRadius da aggiungere al widget
	// arch radius	{"inner":0.6,"outer":0.8}
	
	
	$scope.piechartrender_data = [{key:"One",y:5, color:'#647687'},{key:"Two",y:2, color:'#808e9c'},{key:"Three",y:9, color:'#9ca7b2'},
		{key:"Four",y:7, color:'#b8c0c8'},{key:"Five",y:4, color:'#d4d9de'}];
	
	$scope.piechartrender_options = {chart: {type: 'pieChart',height: 240,showLegend: false,showLabels: false,duration: 500,legendPosition: true,
			startAngle:function(d) { return d.startAngle/$scope.piechartrender.a -  $scope.piechartrender.r*Math.PI/10},
			endAngle: function(d) { return d.endAngle/$scope.piechartrender.a -  $scope.piechartrender.r*Math.PI/10}}};
	
	$scope.updateAngles = function(){
		console.log("updateHalfPie",$scope.piechartrender.angleTypes );
		if($scope.piechartrender.angleTypes=='half'){
			$scope.piechartrender.a = 2;
			//$scope.piechartrender.r = 5;
		}
		else{
			$scope.piechartrender.a = 1;
			//$scope.piechartrender.r = 0;
		}
		$scope.updateRender();
	};
	
	$scope.updateRender = function(){	
		$scope.piechartrender_options.legendPosition = !$scope.piechartrender_options.legendPosition;
		//console.log("updateRender options", $scope.piechartrender_options);

	};
	$scope.updateRender();
	
	
	if(typeof $scope.p.values == 'undefined' || $scope.p.values == null  || $scope.p.values == ""){
	}
	else{
		var parsed = JSON.parse($scope.p.values);

		$scope.piechartrender_options.chart.donut = parsed.donut;
		$scope.piechartrender_options.chart.donutRatio = parsed.donutRatio;
		$scope.piechartrender_options.chart.cornerRadius = parsed.cornerRadius;
		
		if(parsed.halfPie === true){
			$scope.piechartrender.angleTypes = 'half';
			$scope.piechartrender.a = 2;
			if(!parsed.rotation)
				parsed.rotation = 0;
		}
		else if(parsed.section){
			$scope.piechartrender.angleTypes = 'custom';
			$scope.piechartrender.a = parsed.section;
			if(!parsed.rotation)
				parsed.rotation = 0;
		}	
		
		if(parsed.rotation)
			$scope.piechartrender.r = parsed.rotation;
		
		$scope.piechartrender_options.donut = parsed.donut;		
	}
	
	$scope.ok = function () {
		var result = {};
		if($scope.piechartrender_options.chart.donut === true){
			result["donut"] = true; 
			if($scope.piechartrender_options.chart.donutRatio)
				result["donutRatio"] = $scope.piechartrender_options.chart.donutRatio; 
		}
		if($scope.piechartrender.angleTypes=='half'){
			result["halfPie"] = true;
		}
		else if($scope.piechartrender.angleTypes=='custom'){
			result["section"] = $scope.piechartrender.a;
		}
		
		if($scope.piechartrender.r)
			result["rotation"] = $scope.piechartrender.r;

		if($scope.piechartrender_options.chart.cornerRadius)
			result.cornerRadius = $scope.piechartrender_options.chart.cornerRadius;
		
		$scope.p.values = JSON.stringify(result);
	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});
app.controller('DatasetColumnParamDialogInstanceCtrl', function ($scope, metadataapiAPIservice, $uibModalInstance,p, current, isValuecolumn) {
	console.log("p" ,p);	 
	$scope.p = p;
	$scope.isValuecolumn = isValuecolumn;
	if(p.values){
		$scope.column = $scope.$eval(p.values);
	}

	
	var columnsMap = {};
    $scope.getColumns = function(val) {
		var datasetcode = null
		if(Utils.has(current, 'content.params.mandatory.datasetcode.values'))
			datasetcode = current.content.params.mandatory.datasetcode.values;
		
		if(datasetcode){
	    	return metadataapiAPIservice.loadDatasetDetail(datasetcode).then(function(response){
	    		var allColumns = new Array();
	    		for (var i = 0; i < response.data.components.length; i++) {
					if(response.data.components[i].name.includes(val)){
						allColumns.push(response.data.components[i].name);
						columnsMap[response.data.components[i].name] = response.data.components[i].alias;
					}
				}
	    		return allColumns;
		    },
			function(result){
				console.error("loadDatasets error", result);
			});
		}
	};
	  
	$scope.updateColumnLabel = function(){
		if(columnsMap[$scope.column.key])
			$scope.column.label = columnsMap[$scope.column.key];
	}
	  
	$scope.ok = function () {
		var countingMode = "";
		if(isValuecolumn)
			countingMode = ', "countingMode":"'+$scope.column.countingMode+'"';
		$scope.p.values = '{"key":"'+$scope.column.key+'","label":"'+$scope.column.label+'"'+countingMode+'}';
	    $uibModalInstance.close();
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
	
});


