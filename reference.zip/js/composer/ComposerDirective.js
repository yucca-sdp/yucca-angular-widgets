'use strict';

app.directive('paramConfig', function($compile) {
	return {
		restrict : 'E',
		 scope:{
	          directiveType:'@',
	          param: "=", current: "="
	        },
	        link:function(scope,elem, attrs){
		      console.debug("paramConfig",scope.directiveType);
	          var template='<' + scope.directiveType + ' param="param" current="current"></'+ scope.directiveType + '>';
	          template= $compile(template)(scope);
	          elem.replaceWith(template);
	        }
	};
});

app.directive('paramConfigInputtext', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" ng-model-options="{debounce: 750}">', 
	}
});

app.directive('paramConfigInputnumber', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<input type="number" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" ng-model-options="{debounce: 750}">', 
	}
});

app.directive('paramConfigInputpercent', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<div class="input-range input-range-widget-param">' + 
	        		'<input string-to-number type="range" min="0" max="100" step="1" ng-change="updateValues()" class="form-control input-xs" id="i_{{param.name}}" ng-model="par.values" ng-model-options="{debounce: 750}">'+
	        		'<small ng-if="param.values" class="mute nowrap">{{par.values}} &percnt;</small>' +
	        		'</div>', 
	        link:function(scope,elem, attrs){
	        	if(scope.param.values)
	        		scope.par = {values:parseInt(scope.param.values*100)};
	        	
	        	scope.updateValues = function(){
	        		if(scope.par.values)
	        		scope.param.values = scope.par.values/100;
	        	}
	        }
	}
});


app.directive('paramConfigInputboolean', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },  //ng-change='changePrivacy(privacyAcceptance)'
	        template:'<div class="checkbox checkbox-widget-param"><label>'+
				'<input type="checkbox" ng-model="param.values">'+
				'	<span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>'+
				'	<span translate-cloak translate>yes</span>'+
				'</label></div>', 
	}
});


app.directive('paramConfigInputselect', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },  
	        template:'<select ng-model="param.values"  class="form-control input-xs" ng-change="selectChanged(param.values)">'+
				'	<option ng-repeat="opt in param.data track by $index" value="{{opt}}">{{param.name+ "_" +opt|translate}}</option>'+
				'</select>', 
	}
});

app.directive('paramConfigChartaxis', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<div class="inline-input-widget"><div class="checkbox checkbox-widget-param"><label>'+
			'<input type="checkbox" ng-model="par.show" ng-change="updateValues()">'+
			'	<span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>'+
			'	<span translate-cloak translate>param_show_axis</span>'+
			'  </label></div>' +
			'  <label class="ng-hide" translate>param_axis_label</label> '+
			'  <input type="text" ng-model="par.label"   ng-change="updateValues()" ng-disabled="!par.show" placeholder="{{\'param_axis_label\'|translate}}">'+
			'</div>',
	        link:function(scope,elem, attrs){
		        //console.log("paramConfigTenantcode",scope,elem, attrs);
	        	if(scope.param.values)
	        		scope.par = scope.$eval(scope.param.values);
	        	else
	        		scope.par= {"show":false, label: ""};
	        	
	        	scope.updateValues = function(){
	        		if(!scope.par.show)
	        			scope.par.label="";
	        		scope.param.values = JSON.stringify(scope.par);
	        	}
	        }
	}
});

app.directive('paramConfigChartlegend', function($uibModal) {
	return {
		  restrict: 'E',
		  template: '<div  class=" form-control form-control-label-button">'+
			'	<div class="form-control-label" >{{param.values}}</div>'+
			'	<a href ng-click="openMultipleLegendDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
			'</div>',
		  scope: {
			param: '=',
		  },
		  link: function(scope, element, attrs){
			  console.log("legend");
			  scope.openMultipleLegendDialog = function(p){
					console.log("openLegendParamDialog", p);
					$uibModal.open({
						animation: true,
					    templateUrl: 'partials/modal/LegendParamDialog.html',
					    controller: 'LegendParamDialogInstanceCtrl',
					    resolve: {
					    	p: function () {return p;},
					    	type: function(){return 'chart';}
					    }
					});
				};
	      }
		}
});

app.directive('paramConfigMaplegend', function($uibModal) {
	return {
		  restrict: 'E',
		  template: '<div  class=" form-control form-control-label-button">'+
			'	<div class="form-control-label" >{{param.values}}</div>'+
			'	<a href ng-click="openMultipleLegendDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
			'</div>',
		  scope: {
			param: '=',
		  },
		  link: function(scope, element, attrs){
			  console.log("legend");
			  scope.openMultipleLegendDialog = function(p){
					console.log("openLegendParamDialog", p);
					$uibModal.open({
						animation: true,
					    templateUrl: 'partials/modal/LegendParamDialog.html',
					    controller: 'LegendParamDialogInstanceCtrl',
					    resolve: {
					    	p: function () {return p;},
					    	type: function(){return 'map';}
					    }
					});
				};
	      }
		}
});


app.directive('paramConfigInputcolor', function() {
	return {
	  restrict: 'E',
	  template: '<color-picker colorvalue="param.values" />',
	  scope: {
		param: '=', current: '@'
	  },
	}
});

app.directive('paramConfigMultipleinputtext', function($uibModal) {
	return {
	  restrict: 'E',
	  template: '<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label" ng-if="param.values.length<1"><i translate>multivalue_empty</i></div>'+
		'	<div class="form-control-label" ng-if="param.values.length>0">{{param.values}}</div>'+
		'	<a href ng-click="openMultipleParamDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>',
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("colorPicker");
		  scope.openMultipleParamDialog = function(p){
				console.log("openMultipleParamDialog", p);
				var openMultipleParamDialogInstance = $uibModal.open({
					animation: true,
				    templateUrl: 'partials/modal/MultipleParamDialog.html',
				    controller: 'MultipleParamDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;}
				    }
				});
			};
      }
	}
});


app.directive('paramConfigMultiplekeylabeltext', function($uibModal) {
	return {
	  restrict: 'E',
	  template: '<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label" ng-if="param.values.length<1"><i translate>multivalue_empty</i></div>'+
		'	<div class="form-control-label" ng-if="param.values.length>0">{{param.values}}</div>'+
		'	<a href ng-click="openMultiplekeylabelDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>',
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("colorPicker");
		  scope.openMultiplekeylabelDialog = function(p){
				console.log("openMultiplekeylabelDialog", p);
				var openMultipleParamDialogInstance = $uibModal.open({
					animation: true,
					size: 'lg',
				    templateUrl: 'partials/modal/MultipleKeyLabelParamDialog.html',
				    controller: 'MultipleParamDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;}
				    }
				});
			};
      }
	}
});


app.directive('paramConfigMultipleinputcolor', function($uibModal) {
	return {
	  restrict: 'E',
	  template: '<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label" ng-if="param.values.length<1"><i translate>multivalue_empty</i></div>'+
		'	<div class="form-control-label" ng-if="param.values.length>0">'+
		'     <div ng-repeat="c in colors track by $index" class="form-contro-multiple-color-item" style="background-color: {{c}}" title="{{c}}">&nbsp;</div>'+
		'	</div>'+
		'	<a href ng-click="openMultipleParamDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>',
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("colorPicker");
		  scope.colors = new Array();
		  scope.openMultipleParamDialog = function(p){
				console.log("openMultipleParamDialog", p);
				var openMultipleParamDialogInstance = $uibModal.open({
					animation: true,
				    templateUrl: 'partials/modal/MultipleColorParamDialog.html',
				    controller: 'MultipleParamDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;},
				    	inputtype: function(){return 'inputcolor';}
				    }
				});
				openMultipleParamDialogInstance.result.then(function (res) {
					if(scope.param.values)
						scope.colors = scope.$eval(scope.param.values);
					else
						scope.colors = new Array();
				}, function () {
					console.log('Modal dismissed at: ' + new Date());
				});
			};
			
      }
	}
});

app.directive('paramConfigMultiplerangecolor', function($uibModal) {
	return {
	  restrict: 'E',
	  template: '<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label" ng-if="param.values.length<1"><i translate>multivalue_empty</i></div>'+
		'	<div class="form-control-label" ng-if="param.values.length>0">'+
		'     <div ng-repeat="c in colors track by $index" class="form-contro-multiple-color-item" style="background-color: {{c}}" title="{{c}}">&nbsp;</div>'+
		'	</div>'+
		'	<a href ng-click="openMultipleParamDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>',
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("colorPicker");
		  scope.colors = new Array();
		  scope.openMultipleParamDialog = function(p){
				console.log("openMultipleParamDialog", p);
				var openMultipleParamDialogInstance = $uibModal.open({
					animation: true,
				    templateUrl: 'partials/modal/MultipleRangeColorParamDialog.html',
				    controller: 'MultipleParamDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;},
				    	inputtype: function(){return 'inputcolor';}
				    }
				});
				openMultipleParamDialogInstance.result.then(function (res) {
					if(scope.param.values)
						scope.colors = scope.$eval(scope.param.values);
					else
						scope.colors = new Array();
				}, function () {
					console.log('Modal dismissed at: ' + new Date());
				});
			};
			
      }
	}
});

app.directive('paramConfigTenantcode', function(metadataapiAPIservice) {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" uib-typeahead="tenantCode for tenantCode in allTenant | filter:$viewValue | limitTo:8">', 
	        link:function(scope,elem, attrs){
		        console.debug("paramConfigTenantcode param", scope.param);
	        	scope.allTenant = [];
	        	metadataapiAPIservice.loadTenants().then(
	        		function(result){
	        			if(result && result!=null){
	        				try{
	        					var tenantItems = result.data.facetCount.facetFields.tenantCode.facetItems;
	        					angular.forEach(tenantItems, function(count, tenantcode) {
	        						if(count>0)
	        							scope.allTenant.push(tenantcode);
	        					});
	        					scope.allTenant.sort();
	        				}
	        				catch(err){
	        					console.warn("loadTenants error" , err);
	        				} 			
	        			}
	        		},
	        		function(result){
	        			console.error("loadTenants error", result);
	        		}
	        	);
	        }
	};
});

app.directive('paramConfigDatasetcode', function(metadataapiAPIservice) {
	return {
		restrict : 'E',
		 scope:{
			 param: "=", current: "="
	        },
	        template:'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" ' +
	        	' uib-typeahead="datasetCode as datasetCode  for datasetCode in  getDatasets($viewValue) | limitTo:8">', 
	        link:function(scope,elem, attrs){
		        console.debug("paramConfigDatasetcode param", scope.current);
		        
		        scope.getDatasets = function(val) {
		        	console.log("paramConfigDatasetcode::getDatasets", val, scope.current);
		        	var tenantcode = null;
		        	if(Utils.has(scope.current, 'content.params.mandatory_params.tenantcode.name'))
		        		tenantcode = scope.current.content.params.mandatory_params.tenantcode.values;
		        	return metadataapiAPIservice.loadDatasets(tenantcode).then(function(response){
		        		console.log("loadDatasets response",response);
		        		var allDataset = new Array();
		        		for (var i = 0; i < response.data.metadata.length; i++) {
		        			console.log("response.data.metadata", response.data.metadata[i]);
							if(response.data.metadata[i].dataset && response.data.metadata[i].dataset.code.includes(val))
								allDataset.push(response.data.metadata[i].dataset.code);
						}
		        		return allDataset;
				    },
	        		function(result){
	        			console.error("loadDatasets error", result);
	        		});
				  };
		        
		       
	        }
	};
});

app.directive('paramConfigDatasetcolumn', function(metadataapiAPIservice, $uibModal) {
	return {
		restrict : 'E',
		 scope:{
			 param: "=", current: "="
	        },
	        template:'<div  class=" form-control form-control-label-button">'+
			'	<div class="form-control-label">{{param.values}}</div>'+
			'	<a href ng-click="openDatasetColumnDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
			'</div>', 
	        link:function(scope,elem, attrs){
		        //console.log("paramConfigTenantcode",scope,elem, attrs);
		        console.debug("paramConfigDatasetcode param", scope.current);
		        
		        scope.openDatasetColumnDialog = function(p){
					console.log("openDatasetColumnDialog", p);
					var openMultipleParamDialogInstance = $uibModal.open({
						animation: true,
					    templateUrl: 'partials/modal/DatasetColumnParamDialog.html',
					    controller: 'DatasetColumnParamDialogInstanceCtrl',
					    resolve: {
					    	p: function () {return p;},
					    	current: function(){return scope.current},
					    	isValuecolumn: function () {return false;}
					    }
					});
				};
		        		       
	        }
	};
});

app.directive('paramConfigDatasetvaluecolumn', function(metadataapiAPIservice, $uibModal) {
	return {
		restrict : 'E',
		 scope:{
			 param: "=", current: "="
	        },
	        template:'<div  class=" form-control form-control-label-button">'+
			'	<div class="form-control-label">{{param.values}}</div>'+
			'	<a href ng-click="openDatasetColumnDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
			'</div>', 
	        link:function(scope,elem, attrs){
		        //console.log("paramConfigTenantcode",scope,elem, attrs);
		        console.debug("paramConfigDatasetcode param", scope.current);
		        
		        scope.openDatasetColumnDialog = function(p){
					console.log("openDatasetColumnDialog", p);
					var openMultipleParamDialogInstance = $uibModal.open({
						animation: true,
					    templateUrl: 'partials/modal/DatasetColumnParamDialog.html',
					    controller: 'DatasetColumnParamDialogInstanceCtrl',
					    resolve: {
					    	p: function () {return p;},
					    	current: function(){return scope.current},
					    	isValuecolumn: function () {return true;}
					    }
					});
				};
		        		       
	        }
	};
});

app.directive('paramConfigPiechartrender', function($uibModal) {
	return {
	  restrict: 'E',
      template:'<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label">{{param.values}}</div>'+
		'	<a href ng-click="openPiechartrenderDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>', 
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("openPiechartrenderDialog");
		  scope.openPiechartrenderDialog = function(p){
				console.log("openPiechartrenderDialog", p);
				var openMultipleGeojsonDialogInstance = $uibModal.open({
					animation: true,
					size: 'lg',
				    templateUrl: 'partials/modal/PiechartrenderDialog.html',
				    controller: 'PiechartrenderDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;}
				    }
				});
			};
      }
	}
});

app.directive('paramConfigGeojsons', function($uibModal) {
	return {
	  restrict: 'E',
	  template: '<div  class=" form-control form-control-label-button">'+
		'	<div class="form-control-label" ng-if="param.values.length<1"><i translate>multivalue_empty</i></div>'+
		'	<div class="form-control-label" ng-if="param.values.length>0">{{param.values}}</div>'+
		'	<a href ng-click="openGeojsonsParamDialog(param)" class="form-control-button "><i class="fa fa-pencil"></i></a>'+
		'</div>',
	  scope: {
		param: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("geojsonsDialog");
		  scope.openGeojsonsParamDialog = function(p){
				console.log("openGeojsonsDialog", p);
				var openMultipleGeojsonDialogInstance = $uibModal.open({
					animation: true,
				    templateUrl: 'partials/modal/GeojsonsParamDialog.html',
				    controller: 'GeojsonsDialogInstanceCtrl',
				    resolve: {
				    	p: function () {return p;}
				    }
				});
			};
      }
	}
});


app.directive('eventConfigChangecolumn', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<div class="inline-input-widget"><div class="checkbox checkbox-widget-param"><label>'+
			'<input type="checkbox" ng-model="evt.enabled" ng-change="updateValues()">'+
			'	<span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>'+
			'	<span translate-cloak translate>event_enabled</span>'+
			'</label></div>' +
			'<div class="checkbox checkbox-widget-param"><label>'+
			'<input type="checkbox" ng-model="evt.onlySameDataset"   ng-change="updateValues()" ng-disabled="!evt.enabled">'+
			'	<span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>'+
			'	<span translate-cloak translate ng-class="{\'disabled\': !evt.enabled}">event_only_same_dataaset</span>'+
			'</label></div></div>',
	        link:function(scope,elem, attrs){
		        //console.log("paramConfigTenantcode",scope,elem, attrs);
	        	if(scope.param.values)
	        		scope.evt = scope.$eval(scope.param.values);
	        	else
	        		scope.evt = {"enabled":true};
	        	
	        	scope.updateValues = function(){
	        		if(!scope.evt.enabled)
	        			scope.evt.onlySameDataset=false;
	        		scope.param.values = JSON.stringify(scope.evt);
	        	}
	        }

	}
});

app.directive('eventConfigOnlyenable', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<div class="inline-input-widget"><div class="checkbox checkbox-widget-param"><label>'+
			'<input type="checkbox" ng-model="evt.enabled" ng-change="updateValues()">'+
			'	<span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>'+
			'	<span translate-cloak translate>event_enabled</span>'+
			'</label></div></div>',
	        link:function(scope,elem, attrs){
	        	if(scope.param.values)
	        		scope.evt = scope.$eval(scope.param.values);
	        	else
	        		scope.evt = {"enabled":true};
	        	
	        	scope.updateValues = function(){
	        		scope.param.values = JSON.stringify(scope.evt);
	        		console.log("cope.param.values",scope.param.values);
	        	}
	        }
	}
});



//app.directive('paramConfigDatasetcolumn', function(metadataapiAPIservice) {
//	return {
//		restrict : 'E',
//		 scope:{
//			 param: "=", current: "="
//	        },
//	        template:'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" ' +
//	        	' uib-typeahead="datasetCode as datasetCode  for datasetCode in  getColumns($viewValue) | limitTo:8">', 
//	        link:function(scope,elem, attrs){
//		        //console.log("paramConfigTenantcode",scope,elem, attrs);
//		        console.debug("paramConfigDatasetcode param", scope.current);
//		        
//		        scope.getColumns = function(val) {
//		        	console.debug("paramConfigDatasetcode  getColumns", val, scope.current);
//		        	var datasetcode = null
//		        	if(Utils.has(scope.current, 'content.params.mandatory_params.datasetcode.values'))
//		        		datasetcode = scope.current.content.params.mandatory_params.datasetcode.values;
//		        	
//		        	if(datasetcode){
//			        	return metadataapiAPIservice.loadDatasetDetail(datasetcode).then(function(response){
//			        		var allColumns = new Array();
//			        		for (var i = 0; i < response.data.components.length; i++) {
//								if(response.data.components[i].name.includes(val))
//									allColumns.push(response.data.components[i].name);
//							}
//			        		return allColumns;
//					    },
//		        		function(result){
//		        			console.error("loadDatasets error", result);
//		        		});
//		        	}
//				  };
//		        
//		       
//	        }
//	};
//});

app.directive('paramConfigOdatafilter', function() {
	return {
		restrict : 'E',
		 scope:{
			 param: "="
	        },
	        template:'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" >', 
	}
});
// demo suggest with template
//app.directive('paramConfigDatasetcode', function(metadataapiAPIservice) {
//	return {
//		restrict : 'E',
//		 scope:{
//			 param: "=", current: "="
//	        },
//	        template:'<script type="text/ng-template" id="datasetcodeCustomSuggest.html"><a><span>{{match.model.datasetcode}}</span> - <i class="mute">{{match.model.description}}</i></script>'+
//	        	'<input type="text" class="form-control input-xs" id="i_{{param.name}}" ng-model="param.values" ' +
//	        	' typeahead-template-url="datasetcodeCustomSuggest.html" uib-typeahead="datasetCode as datasetCode.datasetcode  for datasetCode in  getDatasets($viewValue) | limitTo:8">', 
//	        link:function(scope,elem, attrs){
//		        //console.log("paramConfigTenantcode",scope,elem, attrs);
//		        console.log("paramConfigDatasetcode param", scope.current);
//		        
//		        scope.getDatasets = function(val) {
//		        	console.log("vak", val, scope.current);
//		        	var tenantcode = null;
//		        	if(Utils.has(scope.current, 'content.params.mandatory_params.tenantcode.name'))
//		        		tenantcode = scope.current.content.params.mandatory_params.tenantcode.values;
//				    console.log("tenatn", tenantcode);
//		        	return metadataapiAPIservice.loadDatasets(tenantcode).then(function(response){
//		        		console.log("re",response);
//		        		var allDataset = new Array();
//		        		for (var i = 0; i < response.data.metadata.length; i++) {
//							if(response.data.metadata[i].dataset.code.includes(val))
//								allDataset.push({datasetcode:response.data.metadata[i].dataset.code,description: response.data.metadata[i].description});
//						}
//		        		return allDataset;
//				    },
//	        		function(result){
//	        			console.error("loadDatasets error", result);
//	        		});
//				  };
//		        
//		       
//	        }
//	};
//});
