'use strict';

var BasicDatasetWidgets = BasicDatasetWidgets || {};


// var currentmillis = new Date().getTime();

// params
var commonParams = {'widget_title': {'name':'widget_title','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
					'widget_subtitle': {'name':'widget_subtitle','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
					'widget_intro': {'name':'widget_intro','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''}
					};

var commonChartParams = {'chart_width':{'name':'chart_width','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
		'chart_height':{'name':'chart_height','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''}
		};


var datasetParams = {'tenantcode':{'name':'tenantcode','type':'tenantcode','mandatory':'true','values':'', 'default':'','custom':''},
		 			 'datasetcode':{'name':'datasetcode','type':'datasetcode','mandatory':'true','values':'', 'default':'','custom':''}
					};

var odataFilterParam = {'grouped_query':{'name':'grouped_query','type':'inputboolean','mandatory':'false','values':'', 'default':'','custom':''},
						'filter':{'name':'filter','type':'odatafilter','mandatory':'false','values':'', 'default':'','custom':''},
						'skip':{'name':'skip','type':'inputnumber','mandatory':'false','values':'', 'default':'0','custom':''},
						'top':{'name':'top','type':'inputnumber','mandatory':'false','values':'', 'default':'','custom':''},
				};

var formatNumberParams = {'euro_value':{'name':'euro_value','type':'inputboolean','mandatory':'false','values':'', 'default':'','custom':''},
						 'decimal_value':{'name':'decimal_value','type':'inputnumber','mandatory':'false','values':'', 'default':'','custom':''},
						 'format_big_number':{'name':'format_big_number','type':'inputboolean','mandatory':'false','values':'', 'default':'','custom':''}
					};

var chartParams = {'main_chart_color':{'name':'main_chart_color','type':'inputcolor','mandatory':'false','values':'', 'default':'','custom':''},
					'chart_colors':{'name':'chart_colors','type':'multipleinputcolor', 'mandatory':'false','values':[], 'default':'','custom':''},
					'show_values':{'name':'show_values','type':'inputboolean','mandatory':'false','values':'', 'default':'','custom':''},
					'chart_legend':{'name':'chart_legend','type':'chartlegend','mandatory':'false','values':'', 'default':'','custom':''}
				};
var chartAxisParams = {'x_axis':{'name':'x_axis','type':'chartaxis','mandatory':'false','values':'', 'default':'','custom':''},
					'y_axis':{'name':'y_axis','type':'chartaxis','mandatory':'false','values':'', 'default':'','custom':''}
			};

var advancedParams = {'usertoken':{'name':'usertoken','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
						'debug':{'name':'debug','type':'inputboolean', 'mandatory':'false','values':[], 'default':'','custom':''}
					 };

// styles
var commonStyles = {'yucca_widget_header_title':{'name':'yucca_widget_header_title','selector':'.yucca-widget-header','custom':''},
					'yucca_widget_header_subtitle':{'name':'yucca_widget_header_subtitle','selector':'.yucca-widget-header small','custom':''},
					'yucca_widget_intro':{'name':'yucca_widget_intro','selector':'.yucca-widget-intro','custom':''},
					'yucca_widget_footer':{'name':'yucca_widget_footer','selector':'.yucca-widget-footer','custom':''},		
					'yucca_widget_footer_text':{'name':'yucca_widget_footer_text','selector':'.yucca-widget-footer-text','custom':''},		
};

var chartStyles = {'yucca-widget-chart-content':{'name':'yucca-widget-chart-content','selector':'.yucca-widget-chart-content','custom':''},
					'yucca-widget-chart':{'name':'yucca-widget-chart','selector':'.yucca-widget-chart','custom':''}		
		};





var basicDatasetDiscretebarChartParams = {
		'value_column':{'name':'value_column','type':'datasetvaluecolumn','mandatory':'true','values':'', 'default':'','custom':''},
		'group_by_column':{'name':'group_by_column','type':'datasetcolumn','mandatory':'true','values':'', 'default':'','custom':''},
};

basicDatasetDiscretebarChartParams = angular.extend({},datasetParams, basicDatasetDiscretebarChartParams);


var basicDatasetDiscretebarChart = {
	key: 'basicDatasetDiscretebarChart',	
	name: 'widget_basic_discretebar',
	directive: 'ng-yucca-dataset-discretebar-chart',
	features: ['table'],
	params: {mandatory: basicDatasetDiscretebarChartParams,
			common: angular.extend({}, commonParams,commonChartParams),
			chart: angular.extend({},chartParams,chartAxisParams),
			odatafilter: odataFilterParam,
			number_format: formatNumberParams,
			advanced: advancedParams},
	events: {
		'event_listening':{
			'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
			'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
			'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
			'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
		},
		'event_sending':{
			'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
		}
	},
	styles: {
		common: commonStyles,
		chart: chartStyles
	}
};
	
BasicDatasetWidgets['basicDatasetDiscretebarChart'] = basicDatasetDiscretebarChart;


// Piechart	
var basicDatasetPieChartParams = {
		'value_column':{'name':'value_column','type':'datasetvaluecolumn','mandatory':'true','values':'', 'default':'','custom':''},
		'group_by_column':{'name':'group_by_column','type':'datasetcolumn','mandatory':'true','values':'', 'default':'','custom':''}
};

var basicDatasetPieChartChartParams = {
		'render':{'name':'render','type':'piechartrender','mandatory':'false','values':'', 'default':'','custom':''},
		'label_threshold':{'name':'label_threshold','type':'inputpercent','mandatory':'false','values':'', 'default':'','custom':''},

}

basicDatasetPieChartParams = angular.extend({},datasetParams, basicDatasetPieChartParams);
var basicDatasetPieChart = {
		key: 'basicDatasetPieChart',	
		name: 'widget_basic_discretebar',
		directive: 'ng-yucca-dataset-pie-chart',
		features: ['chart'],
		params: {mandatory: basicDatasetPieChartParams,
				common: angular.extend({}, commonParams,commonChartParams),
				chart: angular.extend({},basicDatasetPieChartChartParams,chartParams),
				odatafilter: odataFilterParam,
				number_format: formatNumberParams,
				advanced: advancedParams},
		events: {
			'event_listening':{
				'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			},
			'event_sending':{
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			}
		},
		styles: {
			common: commonStyles,
			chart: chartStyles
		}
	};

BasicDatasetWidgets['basicDatasetPieChart'] = basicDatasetPieChart;


// linechart
var basicDatasetLineChartParams = {
		'value_column':{'name':'value_column','type':'datasetvaluecolumn','mandatory':'true','values':'', 'default':'','custom':''},
		'group_by_column':{'name':'group_by_column','type':'datasetcolumn','mandatory':'true','values':'', 'default':'','custom':''}
};

var basicDatasetLineChartChartParams = {
		'render':{'name':'render','type':'piechartrender','mandatory':'false','values':'', 'default':'','custom':''},
		'label_threshold':{'name':'label_threshold','type':'inputpercent','mandatory':'false','values':'', 'default':'','custom':''},

}

basicDatasetLineChartParams = angular.extend({},datasetParams, basicDatasetLineChartParams);
var basicDatasetLineChart = {
		key: 'basicDatasetLineChart',	
		name: 'widget_basic_discretebar',
		directive: 'ng-yucca-dataset-line-chart',
		features: ['chart'],
		params: {mandatory: basicDatasetLineChartParams,
				common: angular.extend({}, commonParams,commonChartParams),
				chart: angular.extend({},basicDatasetLineChartChartParams,chartParams),
				odatafilter: odataFilterParam,
				number_format: formatNumberParams,
				advanced: advancedParams},
		events: {
			'event_listening':{
				'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			},
			'event_sending':{
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			}
		},
		styles: {
			common: commonStyles,
			chart: chartStyles
		}
	};

BasicDatasetWidgets['basicDatasetLineChart'] = basicDatasetLineChart;


// treemap
var basicDatasetTreemapChartParams = {
		'value_column':{'name':'value_column','type':'datasetvaluecolumn','mandatory':'true','values':'', 'default':'','custom':''},
		'group_by_column':{'name':'group_by_column','type':'datasetcolumn','mandatory':'true','values':'', 'default':'','custom':''}
};

var basicDatasetTreemapChartChartParams = {
		'render':{'name':'render','type':'piechartrender','mandatory':'false','values':'', 'default':'','custom':''},
		'label_threshold':{'name':'label_threshold','type':'inputpercent','mandatory':'false','values':'', 'default':'','custom':''},

}

basicDatasetTreemapChartParams = angular.extend({},datasetParams, basicDatasetTreemapChartParams);
var basicDatasetTreemapChart = {
		key: 'basicDatasetTreemapChart',	
		name: 'widget_basic_discretebar',
		directive: 'ng-yucca-dataset-line-chart',
		features: ['chart'],
		params: {mandatory: basicDatasetTreemapChartParams,
				common: angular.extend({}, commonParams,commonChartParams),
				chart: angular.extend({},basicDatasetTreemapChartChartParams,chartParams),
				odatafilter: odataFilterParam,
				number_format: formatNumberParams,
				advanced: advancedParams},
		events: {
			'event_listening':{
				'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			},
			'event_sending':{
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			}
		},
		styles: {
			common: commonStyles,
			chart: chartStyles
		}
	};

BasicDatasetWidgets['basicDatasetTreemapChart'] = basicDatasetTreemapChart;