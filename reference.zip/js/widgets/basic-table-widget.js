'use strict';

var BasicTableWidgets = BasicTableWidgets || {};

// params
var advancedParams = {'usertoken':{'name':'usertoken','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
						'debug':{'name':'debug','type':'inputboolean', 'mandatory':'false','values':[], 'default':'','custom':''}
					 };

// styles
var tableStyles = {'yucca-widget-table-content':{'name':'yucca-widget-table-content','selector':'.yucca-widget-table-content','custom':''},
		'yucca-widget-table':{'name':'yucca-widget-table','selector':'.yucca-widget-table','custom':''},	
		'yucca-widget-table-header-row':{'name':'yucca-widget-table-header-row','selector':'.yucca-widget-table thead tr','custom':''},	
		'yucca-widget-table-header-cell':{'name':'yucca-widget-table-header-cell','selector':'.yucca-widget-table  thead th','custom':''},	
		'yucca-widget-table-body-row':{'name':'yucca-widget-table-body-row','selector':'.yucca-widget-table  tbody tr','custom':''},	
		'yucca-widget-table-body-cell':{'name':'yucca-widget-table-body-cell','selector':'.yucca-widget-table tbody td','custom':''},	

};





var basicTableDistributionParams = {
		'value_column':{'name':'value_column','type':'datasetvaluecolumn','mandatory':'true','values':'', 'default':'','custom':''},
		'group_by_column':{'name':'group_by_column','type':'datasetcolumn','mandatory':'true','values':'', 'default':'','custom':''},
};

basicTableDistributionParams = angular.extend(datasetParams, basicTableDistributionParams);

var basicDistributionTable = {
	key: 'basicDistributionTable',	
	name: 'widget_basic_distribution',
	directive: 'ng-yucca-distribution-table',
	//directiveUrl: function(){return 'widget/'+this.key+'.html';},
	features: ['chart'],
	params: {mandatory: basicDatasetDiscretebarChartParams,
			common: commonParams,
			odatafilter: odataFilterParam,
			number_format: formatNumberParams,
			advanced: advancedParams},
	events: {
		'event_listening':{
			'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
			'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
			'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
		},
		'event_sending':{
			'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
		}
	},
	styles: {
		common: commonStyles,
		table: tableStyles
	}
};
	
BasicTableWidgets['basicDistributionTable'] = basicDistributionTable;


