'use strict';

var BasicControlWidgets = BasicControlWidgets || {};




//var currentmillis = new Date().getTime();

// params
var commonBasicControlParams = {'label': {'name':'label','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
					'hint': {'name':'hint','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''}
					};

// styles
var commonBasicControlStyles = {'yucca-control-header-title':{'name':'yucca-control-header-title','selector':'.yucca-control-main-header .yucca-control-main-label','custom':''},
					'yucca-control-header-subtitle':{'name':'yucca-control-header-subtitle','selector':'.yucca-control-main-header .yucca-control-main-hint','custom':''}
};




// basic control select
var basicControlSelectMandatoryParams = {
		'value_columns':{'name':'value_columns','type':'multiplekeylabeltext','mandatory':'true','values':'', 'default':'','custom':''}
};

var basicControlSelectParams = {'selected_value': {'name':'selected_value','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
		'select_empty_label': {'name':'select_empty_label','type':'inputtext','mandatory':'false','values':'', 'default':'','custom':''},
		'render': {'name':'render','type':'inputselect','mandatory':'false','values':'', 'default':'','data':['select','radio','button']},
		'direction': {'name':'direction','type':'inputselect','mandatory':'false','values':'', 'default':'','data':['row','column']},
		};

basicControlSelectParams = angular.extend(commonBasicControlParams, basicControlSelectParams);


var commonBasicControlSelectRadioStyles = {
		'yucca-control-select-radio-panel':{'name':'yucca-control-select-radio-panel','selector':'.yucca-control-type-radio  .yucca-control-items','custom':''},
		'yucca-control-select-radio-item':{'name':'yucca-control-select-radio-item','selector':'.yucca-control-type-radio  .radio.yucca-control-item','custom':''},
};

var commonBasicControlSelectTabbuttonStyles = {
		'yucca-control-select-tabbutton-panel':{'name':'yucca-control-select-tabbutton-panel','selector':'.yucca-control-type-button  .yucca-control-items','custom':''},
		'yucca-control-select-tabbutton-item':{'name':'yucca-control-select-tabbutton-item','selector':'.yucca-control-type-radio  .yucca-control-select-button','custom':''},
		'yucca-control-select-tabbutton-item-selected':{'name':'yucca-control-select-tabbutton-item-selected','selector':'.yucca-control-type-radio  .yucca-control-select-button .active','custom':''},
};

var commonBasicControlSelectSelectStyles = {
		'yucca-control-select-select-panel':{'name':'yucca-control-select-select-panel','selector':'.yucca-control-type-select','custom':''},
		'yucca-control-select-select':{'name':'yucca-control-select-select','selector':'.yucca-control-type-select  .yucca-select-select-button','custom':''},
};




var basicControlSelect = {
	key: 'basicControlSelect',	
	name: 'control_basic_select',
	directive: 'ng-yucca-control-select',
	//directiveUrl: function(){return 'widget/'+this.key+'.html';},
	//directiveUrl: 'widget/basic/basicDatasetDiscretebarChart.html?time='+currentmillis,
	features: ['control'],
	params: {mandatory: basicControlSelectMandatoryParams,
			common: basicControlSelectParams},
	events: {},
	styles: {
		common_basic_control: commonBasicControlStyles,
		basic_control_radio: commonBasicControlSelectRadioStyles,
		basic_control_tabbutton: commonBasicControlSelectTabbuttonStyles,
		basic_control_select: commonBasicControlSelectSelectStyles,
	}
};
	
BasicControlWidgets['basicControlSelect'] = basicControlSelect;
	
