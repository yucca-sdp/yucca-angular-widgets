'use strict';

var Widgets = Widgets ||  {};

Widgets["dataset"]  =  BasicDatasetWidgets;
Widgets["geo"]  =  BasicGeoWidgets;
Widgets["table"] = BasicTableWidgets;
Widgets["control"]  =  BasicControlWidgets;
Widgets["htmlelement"]  =  HtmlElementWidgets;
Widgets["advanced"]  =  AdvancedWidgets;



