'use strict';

var HtmlElementWidgets = HtmlElementWidgets || {};

var text = {
	key: 'text',	
	name: 'html_text',
	html: function(){return '<div class="yucca-html_text">' + this.params.content.values + '</div>';},
	params: {'content': {'name':'content','multiple': 'false', 'key_value': 'false','mandatory':'false','values':'Text', 'default':'','custom':''}},
	advancedParams: {},
	styles: {'yucca-html_text':{'name':'yucca-html_text','desc':'yucca-html_text','custom':''}}
};

var image = {
	key: 'image',	
	name: 'html_image',
	html: function(){return '<img src="' + this.params.imageurl.values + '" />';},
	params: {'imageurl': {'name':'imageurl','multiple': 'false', 'key_value': 'false','mandatory':'false','values':'/images/img-placeholder.png', 'default':'','custom':''}},
	advancedParams: {},
	styles: {'yucca-html_text':{'name':'yucca-html_text','desc':'yucca-html_text','custom':''}}
};

HtmlElementWidgets['text'] = text;
HtmlElementWidgets['image'] = image;
	

var basicDatasetDiscretebarChart = {
		key: 'basicDatasetDiscretebarChart',	
		name: 'widget_basic_discretebar',
		directive: 'ng-yucca-dataset-discretebar-chart',
		//directiveUrl: function(){return 'widget/'+this.key+'.html';},
		directiveUrl: 'widget/basic/basicDatasetDiscretebarChart.html?time='+currentmillis,
		features: ['chart'],
		params: {mandatory: basicDatasetDiscretebarChartParams,
				common: commonParams,
				chart: chartParams,
				odatafilter: odataFilterParam,
				number_format: formatNumberParams,
				advanced: advancedParams},
		events: {
			'event_listening':{
				'evt_change_valuecolumn':{'name':'evt_change_valuecolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_change_groupbycolumn':{'name':'evt_change_groupbycolumn','type':'changecolumn', 'values':'{"enabled":true}'},
				'evt_filter_text':{'name':'evt_filtertext','type':'onlyenable', 'values':'{"enabled":true}'},
			},
			'event_sending':{
				'evt_highlight_groupbycolumn':{'name':'evt_highlight_groupbycolumn','type':'onlyenable', 'values':'{"enabled":true}'},
			}
		},
		styles: {
			common: commonStyles,
			chart: chartStyles
		}
	};
		


