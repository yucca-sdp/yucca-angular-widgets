var Constants = Constants || {};

Constants.chartColorsDefault = ["#004586","#0084d1", "#d01e2a", "#f37a1f", "#f3c414", "#3d9e00", "#a6d615","#8f69c2","#e4477e"];

Constants.timeRangeValues = ['today','yesterday','this_month','last_month','this_year','last_year'];
