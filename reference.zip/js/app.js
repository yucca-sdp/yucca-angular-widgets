'use strict';

// Declare app level module which depends on views, and components
var app  = angular.module('YuccaReference', [
  'ngRoute',
  'ngSanitize',
  'ui.bootstrap',
  'pascalprecht.translate',
  'yucca.plugin',
  'ngDraggable',
  'angular-bind-html-compile',
  'angularFileUpload'
]);
  

var supportedLanguages = ['it', 'en'];
/** config */
app.config(['$translateProvider', function ($translateProvider) {
	// add translation table
	$translateProvider
	.translations('en', translations_en)
	.translations('it', translations_it)
	.preferredLanguage('it');
}]);

app.config(['$routeProvider', '$translateProvider', function($routeProvider, $translateProvider) {
	//$routeProvider.when('/home', {templateUrl: 'partials/home.html'});
	$routeProvider.when('/install', {templateUrl: 'partials/install.html', currentSection: 'install'});
	$routeProvider.when('/widget', {templateUrl: 'partials/widgets.html',controller: 'WidgetCtrl', currentSection: 'widget'});
	$routeProvider.when('/widget/:selected_section/:selected_widget', {templateUrl: 'partials/widget.html',controller: 'WidgetCtrl', currentSection: 'widget'});
	$routeProvider.when('/composer/', {templateUrl: 'partials/composer.html',controller: 'ComposerCtrl', currentSection: 'composer'});
	$routeProvider.otherwise({redirectTo: '/install'});
}]);



app.run(function($rootScope, $location, $anchorScroll) {
  $rootScope.$on('$routeChangeSuccess', function(newRoute, oldRoute) {
    if($location.hash()) $anchorScroll();  
  });
});

/** directive */
app.directive('mainHeader', function() {
	return {
		restrict : 'E',
		templateUrl : 'partials/main-header.html',
	};
});

app.directive('mainFooter', function() {
	return {
		restrict : 'E',
		templateUrl : 'partials/main-footer.html',
	};
});

app.directive('colorPicker', function() {
	return {
	  restrict: 'E',
	  template: '<div class="color-picker-widget-param input-group input-group-sm" >'+
	    '  <input type="color" ng-model="colorvalue" class="form-control input-xs" > '+
		'  <div class="input-group-btn" uib-dropdown> '+
		'    <button type="button" class="btn dropdown-toggle" uib-dropdown-toggle>'+
		'  	   <span class="caret"></span>'+
		'    </button>'+
		'    <ul class="dropdown-menu" role="menu" uib-dropdown-menu >'+
		'      <li ng-repeat="line in defaultColors track by $index">'+
		'        <div class="default-color-box" ng-repeat="c in line track by $index" style="background-color: {{c}}" ng-click="selectColor(c)"></div>' + 
		'      </li>'+
		'      <li><a href ng-click="clearColor()"><i class="fa fa-clear"></i>Reset</a></li>'+
		'    </ul>'+
		'  </div>'+
		'</div>',
	  scope: {
		colorvalue: '=',
	  },
	  link: function(scope, element, attrs){
		  console.log("colorPicker");
		  
		 scope.defaultColors = [["#fce94f","#edd400","#c4a000"],
			 ["#fcaf3e","#f57900","#ce5c00"],
			 ["#e9b96e","#c17d11","#8f5902"],
			 ["#8ae234","#73d216","#4e9a06"],
			 ["#729fcf","#3465a3","#204a87"],
			 ["#ad7fa8","#75507b","#5c3566"],
			 ["#ef2929","#cc0000","#a40000"]];
//				 ["#eeeeec","#d3d7cf","#babdb6"],
//				 ["#888a85","#555753","#2e3436"]];
		 
		 scope.defaultColors2 = [["#19aeff","#0047c8","#005c94"],
			 ["#ccff42","#9ade00","#009100"],
			 ["#ffff3e","#ff9900","#ff6600"],
			 ["#eccd84","#d49725","#804d00"],
			 ["#ff4141","#dc0000","#b50000"],
			 ["#f1caff","#d76cff","#ba00ff"],
			 ["#9eabb0","#364e59","#0e232e"],
			 ["#cccccc","#999999","#666666"]];
		 
		 scope.defaultColors1 = [["#9e4d44","#f7786b","#fbc1bb"],
			 ["#5d6c85","#91a8d0","#ccd7e9"],
			 ["#023354","#034f84","#8baec6"],
			 ["#a08f26","#fae03c","#fdf1a5"],
			 ["#618d8e","#98ddde","#d0eff0"],
			 ["#616069","#9896a4","#d0cfd5"],
			 ["#8d2a20","#dd4132","#efa8a1"],
			 ["#715c44","#b18f6a","#dbccbb"],
			 ["#4d7f35","#79c753","#c1e5b0"]];

		 scope.selectColor = function(color){
			 scope.colorvalue = color;
		 }		
		 scope.clearColor = function(){
			 scope.colorvalue = null;
		 }
      }
	}
});

app.directive('typeaheadFocus', function () {
	return {
		require: 'ngModel',
			link: function (scope, element, attr, ngModel) {
				element.bind('click', function () {
					var viewValue = ngModel.$viewValue;
					if (ngModel.$viewValue == ' ') {
						ngModel.$setViewValue(null);
					}
					ngModel.$setViewValue(' ');
					ngModel.$setViewValue(viewValue || ' ');
				});

				scope.emptyOrMatch = function (actual, expected) {
					if (expected == ' ') {
						return true;
					}
					return actual.indexOf(expected) > -1;
				};
		    }
		};
});


/** filter */
app.filter('arr2Str', function() {
	return function(input) {
		var res  = input;
		if (input && input!=null) {
			res = input.toString();
	    }
		return res;
	};
});

app.filter('minus2underscore', function () {
	  return function (input) {
			var res  = input;
			if (input && input!=null) {
				res = input.replace(/-/g, '_');
		    }
			return res;
	  };
});

app.filter('string_ellipse', function () {
    return function (text, length, end) {
    	
    	if(typeof text === "undefined"  || text == null)
    		text = "";
    	
        if (isNaN(length))
            length = 10;

        if (end === undefined)
            end = "...";

        if (text.length <= length || text.length - end.length <= length) {
            return text;
        }
        else {
            return String(text).substring(0, length-end.length) + end;
        }
    };
});


/** controller */
app.controller('GlobalCtrl', ['$scope', '$translate', '$location', '$route', '$uibModal', function($scope, $translate, $location,$route,$uibModal) {
 
	$scope.currentLang = 'it';
	var langParam = $location.search().lang;
	if(typeof langParam != 'undefined' && supportedLanguages.indexOf(langParam)>=0){
		$scope.currentLang = langParam;
		$translate.use(langParam);
	}
	
	
	$scope.changeLanguage = function(langKey) {
		$translate.use(langKey);
		$scope.currentLang = langKey;
	};
	
	$scope.currentSection = function() {return $route.current.currentSection;};
	
	$scope.widgetsForMenu = Widgets;
	
	$scope.featureStyle = function(feature){
		var style ="";
		switch (feature) {
		case "social":
			style= 'fa fa-twitter';
			break;
		case "chart":
			style= 'fa fa-bar-chart';
			break;
		case "images":
			style= 'fa fa-picture-o';
			break;
		case "map":
			style= 'fa fa-map-marker';
			break;
		case "websocket":
			style= 'fa fa-rss widget-feature-icon-websocket';
			break;
		case "dataexplorer":
			style= 'fa fa-table';
			break;
		default:
			break;
		}
		return style;
	};
	
	$scope.openWidgetHelp = function(widgetKey){
		$uibModal.open({
			animation: true,
			templateUrl: 'partials/modal/WidgetHelpDialog.html',
		    controller: 'WidgetHelpDialogInstanceCtrl',
		   //size: 'lg',
		    resolve: {
		    	widgetKey: function () {return widgetKey;}
		    }
		});
	};

}]);

app.controller('WidgetCtrl', ['$scope', '$compile', '$route', '$uibModal', '$location', function($scope, $compile, $route, $uibModal, $location) {

	$scope.widgetsReady = false;
	$scope.widgets = Widgets;
	console.log("widgets", $scope.widgets);
	$scope.widgetsReady = true;
	if($route.current.params.selected_section){
		$scope.widget = $scope.widgets[$route.current.params.selected_section][$route.current.params.selected_widget];
		$scope.current = {type: "yucca-widget", content: $scope.widget}; 
	}
	
	$scope.prettifyCss = Utils.prettifyCss;
	$scope.changedParams = false;
	
	$scope.currentmillis = new Date().getTime();
	$scope.accordions = {"widget": {"basic":true}, "htmlelement": false, "params": {"mandatory_params":true}, "events": {"event_listening":true, "event_sending": true}, "export": false};

	
	$scope.changeParamEvent = function(){
		$scope.changedParams = true;
	};
	
	$scope.refreshPreview = function(widgetKey){
		var changedDirectiveUrl = Widgets[widgetKey].directiveUrl+'?t='+new Date().getTime();
		Widgets[widgetKey].directiveUrl = changedDirectiveUrl;
		$scope.changedParams = false;
	}; 

//	for (var i = 0; i < 16; i++) {
//		console.log("- ", i, i%4);
//	}
//	$scope.borderInGrid = function(cellIndex){
//		var style = "";
//		if(cellIndex%4 != 0)
//			style += "widget-menu-item-border-left ";
//		if(cellIndex>3)
//			style += "widget-menu-item-border-top ";
//		return style;
//	}

	$scope.changedStyle = "";
	$scope.openChangeStyleDialog = function(widgetKey, styleSection, styleName){
		console.log(widgetKey, styleName);
		var modalInstance = $uibModal.open({
			animation: true,
		    templateUrl: 'partials/modal/ChangeStyleDialog.html',
		    controller: 'ChangeStyleDialogInstanceCtrl',
		    resolve: {
		    	widgetKey: function () {return widgetKey;},
		    	styleSection: function () {return styleSection;},
		    	styleName: function () {return styleName;},
		    	existingRules: function(){return $scope.widget.styles[styleSection][styleName].custom;}
		    }
		});
		
		modalInstance.result.then(function (res) {
			console.log("result",res);
		    $scope.widget.styles[styleSection][res.styleName].custom = res.rule;
		}, function () {
			$log.info('Modal dismissed at: ' + new Date());
		});
	};
	
	$scope.isComponentReady = function(c){
		var isReady  = true;
		if(c && c.content && c.content.params){
			for (var paramSectionKey in c.content.params) {
			    if (c.content.params.hasOwnProperty(paramSectionKey)) {
			    	var paramSection = c.content.params[paramSectionKey];
					for (var paramKey in paramSection) {
					    if (paramSection.hasOwnProperty(paramKey)) {
			    	
					    	var v = paramSection[paramKey].values;
					    	
					    	if(paramSection[paramKey].mandatory == "true" && (v == null || v.length==0)){
					    		isReady  = false;
					    		break;
					    	}
					    }
					}
			    }
			}
			
		}
		return isReady;
	}

	$scope.chooseWidget = function(widgetSection, widgetKey){
		$location.path("/widget/" + widgetSection + "/" +widgetKey);
	};
	
	
	$scope.widgetCode = function(){
		var widgetCodeRaw = Utils.widget.getWidgetCodeRaw($scope.current);
		return Utils.render.prettifyHtml(widgetCodeRaw);
	};
	$scope.widgetStyle = function(){
		var widgetCssRaw = Utils.widget.getWidgetCssRaw($scope.current);
		return Utils.render.prettifyCss(widgetCssRaw);
	};
	
	$scope.getHtmlContent = function(c){
		return Utils.widget.getWidgetCodeRaw(c);
	}

	

}]);

app.controller('WidgetHelpDialogInstanceCtrl', function ($scope, $uibModalInstance,widgetKey) {

	console.log("WidgetHelpDialogInstanceCtrl - widgetKey" ,widgetKey);	  

	$scope.widgetKey = widgetKey;
	$scope.ok = function () {
	    $uibModalInstance.close();
	};

});

app.controller('ChangeStyleDialogInstanceCtrl', function ($scope, $uibModalInstance,widgetKey, styleSection,styleName, existingRules) {

	console.log("widgetKey,  styleName" ,widgetKey, styleSection, styleName, existingRules);	  
	
	var createCssRule = function(key, value, append){
		var rule = "";
		if(typeof value != 'undefined' && value !=null && value != ''){
			rule = key + ":" + value + append + ";";
		}
		return rule + " ";
	};
	
	
	
	var updateRules  = function () {
		var rule = "";
		if($scope.customStyle){
			if($scope.customStyle.font){	
				if($scope.customStyle.font.size)
					rule += createCssRule("font-size", $scope.customStyle.font.size, "px");
				if($scope.customStyle.font.weight)
					rule += createCssRule("font-weight", "bold","");
				if($scope.customStyle.font.style)
					rule += createCssRule("font-style", "italic","");
			}
			if($scope.customStyle.textAlign)
				rule += createCssRule("text-align", $scope.customStyle.textAlign,"");
			if($scope.customStyle.color){
				if($scope.customStyle.color.foreground)
					rule += createCssRule("color", $scope.customStyle.color.foreground,"");
				if($scope.customStyle.color.background)
					rule += createCssRule("background", $scope.customStyle.color.background,"");
				
			}

		    if($scope.customStyle.border && $scope.customStyle.border.position){
		    	if(!$scope.customStyle.border.width)
		    		$scope.customStyle.border.width=1;
		    	if(!$scope.customStyle.border.color)
		    		$scope.customStyle.border.color="#000";
		    	if(!$scope.customStyle.border.style)
		    		$scope.customStyle.border.style='solid';
		    	
			    rule += createCssRule("border-color", $scope.customStyle.border.color,"");
			    rule += createCssRule("border-style", $scope.customStyle.border.style,"");
			    
			    if($scope.customStyle.border.position == 'top')
				    rule += createCssRule("border-width", $scope.customStyle.border.width + "px 0 0 0","");
			    else if($scope.customStyle.border.position == 'right')
				    rule += createCssRule("border-width", "0 " + $scope.customStyle.border.width + "px 0 0","");
			    else if($scope.customStyle.border.position == 'bottom')
				    rule += createCssRule("border-width", "0 0 " + $scope.customStyle.border.width + "px 0","");
			    else if($scope.customStyle.border.position == 'left')
				    rule += createCssRule("border-width", "0 0 0 " + $scope.customStyle.border.width + "px","");
			    else if($scope.customStyle.border.position == 'top-bottom')
				    rule += createCssRule("border-width", $scope.customStyle.border.width + "px 0","");
			    else if($scope.customStyle.border.position == 'left-right')
				    rule += createCssRule("border-width", " 0 " + $scope.customStyle.border.width + "px","");
			    else if($scope.customStyle.border.position == 'all')
				    rule += createCssRule("border-width", $scope.customStyle.border.width + "px","");
			    else if($scope.customStyle.border.position == 'none')
				    rule += createCssRule("border", "none","");
	
			    	
	
		    }
		}
	    return rule;
	};
	
	$scope.refreshPreview = function(){
		$scope.rulesPreview = updateRules();
		if($scope.rulesPreview)
			$scope.rulesCodePreview = $scope.rulesPreview.replace(new RegExp("; ", 'g'), ";<br>");
	};
	
	if(existingRules){
		try{
			$scope.customStyle = {font:{}, color:{}, border: {}};
			var ruleArr = existingRules.split("; ");
			for(var i=0; i<ruleArr.length; i++){
				var r=ruleArr[i].split(":");
				if(r[0] == 'font-size')
					$scope.customStyle.font.size = parseInt(r[1].replace("px",""));
				else if(r[0] == 'font-weight')
					$scope.customStyle.font.weight = true;
				else if(r[0] == 'font-style')
					$scope.customStyle.font.style= true;
				else if(r[0] == 'text-align')
					$scope.customStyle.textAlign = r[1];
				else if(r[0] == 'color')
					$scope.customStyle.color.foreground = r[1];
				else if(r[0] == 'background')
					$scope.customStyle.color.background = r[1];
				else if(r[0] == 'text-align')
					$scope.customStyle.textAlign = r[1];
				else if(r[0] == 'border-color')
					$scope.customStyle.border.color = r[1];
				else if(r[0] == 'border-style')
					$scope.customStyle.border.style= r[1];
				else if(r[0] == 'border' && r[1] == 'none' )
					$scope.customStyle.border.position = r[1];
				else if(r[0] == 'border-width'){
					var borderWidths = r[1].split(" ");
					if(borderWidths.length==1){
						$scope.customStyle.border.width = parseInt(borderWidths[0].replace("px",""));
						$scope.customStyle.border.position = 'all';
					}
					else if(borderWidths.length==2){
						if(borderWidths[0] == 0){
							$scope.customStyle.border.width = parseInt(borderWidths[1].replace("px",""));
							$scope.customStyle.border.position = 'left-right';
						}
						else if(borderWidths[1] == 0){
							$scope.customStyle.border.width = parseInt(borderWidths[0].replace("px",""));
							$scope.customStyle.border.position = 'top-bottom';
						}
					}
					else if(borderWidths.length==4){
						var borderPosition = ['top', 'right', 'bottom', 'left'];
						for (var j = 0; j < borderWidths.length; j++) {
							if(borderWidths[j]!=0){
								$scope.customStyle.border.width = parseInt(borderWidths[j].replace("px",""));
								$scope.customStyle.border.position = borderPosition[j];
								break;
							}
						}
					}
				}
			}
			$scope.refreshPreview();
		}
		catch (e) {
			console.error("ChangeStyleDialogInstanceCtrl error in parsing existing rule", existingRules);
		}
		

		
	}
	
	

	$scope.ok = function () {
	    $uibModalInstance.close({"widgetKey":widgetKey, "styleSection":styleSection, "styleName": styleName, "rule": updateRules() });
	};
	
	$scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	};
});



app.factory('readFilePreview', function($q) {
	return {
		readTextFile: function (file, previewSize, encoding) {
			var deferread = $q.defer();
			if (window.File && window.FileReader && window.FileList && window.Blob) {
				var reader = new FileReader();
				console.log("file", file);
				if ((file !== undefined) && (file !== null)) {
					reader.onload = function (event) {

						deferread.resolve(event.target.result);
					};
					var firstBytes = file.slice(0, previewSize + 1);
					reader.readAsText(firstBytes, encoding);
				}else{
					console.log("reject", file);
					deferread.reject("You need to pass a file.");
				}
			}else{
				deferread.reject("Your browser don't support File api.");
			}

			return deferread.promise;
		}
	};
});