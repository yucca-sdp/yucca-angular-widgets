var translations_it = {

	LANG_KEY : 'it',

	/* common */
	Welcome : 'Benvenuti',
	Preview: 'Anteprima',
	getting_started: 'Per iniziare',
	composer: 'Composer',
	yucca_credits_intro : 'Footer',
	active: 'css class for the active menu item',
	yes: 'Si',
	not_visible: 'Non visibile',
	
	widget_social:'Social',
	widget_gallery:'Galleria',
	widget_multidata:'Multidata',
	widget_lastvalue:'Ultimo valore',
	widget_detection:'Rilevamento',
	widget_monitor:'Andamento',
	widget_map:'Mappa',
	widget_treemap:'Treemap',
	widget_multidata_treemap:'Treemap Multidata',
	widget_bulletchart:'Bullet chart',
	widget_sankeychart:'Diagramma di Sankey',
	widget_population_pyramid:'Piramide delle et&agrave;',
	widget_choropleth_map:'Mappa coropletica',
	widget_forcedirected_chart:'Diagramma force-directed',
	widget_dataexplorer: 'Data Explorer',
	widget_controlfilter: 'Filtro sui dati',

	/* widget cards */
	widget_info_tab_use : 'Utilizzo',
	widget_info_tab_params : 'Parametri',
	widget_info_tab_advanced_params : 'Avanzate',
	widget_info_tab_customize : 'Configura',
	widget_info_tab_style : 'Personalizza',
	widget_info_change_param_warning : 'Hai cambiato dei parametri, aggiorna la preview',

	widget_intro : 	'<p>Yucca si arricchisce di una famiglia di widget che gli sviluppatori potranno utilizzare per rappresentare i dati di interesse.</p>'
			+ '<p>In questa sezione abbiamo realizzato una <strong>Dashboard</strong> che in modo didattico mostra alcuni dati presenti in Yucca, attraverso i formati predisposti'
			+' con i widget ad oggi utilizzabili.'
			+ '<p>Nei pannelli <strong>Parametri</strong> e <strong>Avanzate</strong> si possono inserire i parametri da utilizzare per la configurazione del widget, ricordando che alcuni parametri sono obbligatori, '
			+ ' (ad esempio, il codice del dataset o dello stream), altri sono opzionali. Una volta inseriti i parametri, nella sezione <strong>anteprima</strong> del widget compare il codice da incorporare nella pagina html '
			+ '<p>Tutti i widget sono altamente personalizzabili, nella scelta dei dati da visualizzare, e nell\'aspetto finale dei widget. Tramite il pannello <strong>Personalizza</strong>'
			+ ' &egrave; possibile provare a modificare lo stile del widget, e vederne il risultato in tempo reale. Una volta completata la personalizzazione si pu&ograve; copiare il codice da inserire nel proprio foglio di stile</p>'
			+ '<p>Ogni widget ha il parametro <code><strong>user_token</strong></code> che permette di accedere ai dati privati, e un parametro'
			+ '<code><strong>debug</strong></code>, da utilizzare in fase di installazione, che permette di vedere eventuali errori di configurazione direttamente nel widget stesso' 
			+ '<p>Se si utilizzano pi&ugrave; widget nella stessa pagina, &egrave; importante che siano separati in pannelli diversi</p>',


	/* Change syle dialog */
	change_style_dialog_title: 'Personalizza',
	change_style_dialog_text: 'Testo',
	change_style_dialog_text_align: 'Allineamento',
	change_style_dialog_text_size: 'Dimensione',
	change_style_dialog_text_style: 'Stile',
	change_style_dialog_colors: 'Colori',
	change_style_dialog_borders: 'Bordi',
	
	yucca_widget_intro: 'Descrizione introduttiva',

	/* *********** */
	/* TWEET STATS */
	/* *********** */
	streamTweetStats_intro : '<p>Widget pensato per la visualizzazione delle statistiche legate agli <strong>stream social twitter</strong></p>'
			+ '<p>Si presenta con <strong>un grafico che visualizza il numero di tweet  in un asse temporale</strong>, con la possibilit&agrave; '
			+ 'di specificare il range desiderato (ultimo mese, ultimo giorno...), o un intervallo preciso di date. '
			+ 'In assenza di specifiche, il widget elabora i tweet del giorno, il widget elabora i tweet del giorno</p>'
			+ '<p>In evidenza vengono inoltre proposti due pannelli he visualizzano gli <strong>ultimi tweet</strong> e i <strong>tweet pi&ugrave; ritwittati</strong></p>',

	/* params */
	streamTweetStats_widget_title : 'Titolo del widget',
	streamTweetStats_widget_intro: 'Descrizione introduttiva',
	streamTweetStats_tenant_code : 'Codice tenant dello stream',
	streamTweetStats_stream_code : 'Codice dello stream',
	streamTweetStats_smartobject_code : 'Codice dello Smartobject',
	streamTweetStats_landing_panel: 'Pannello visualizzato al caricamento del widget',
	streamTweetStats_time_range : 'Intervallo di tempo su cui calcolare la statistica, in alternativa ai parametri di data minima  e data massima',
	streamTweetStats_time_min_date : 'Data iniziale dell\intervallo su cui calcolare la statistica in formato ISO: YYYY-MM-DD o YYYY-MM-DDTHH:MM:SS',
	streamTweetStats_time_max_date : 'Data finale dell\intervallo su cui calcolare la statistica in formato ISO: YYYY-MM-DD o YYYY-MM-DDTHH:MM:SS',
	streamTweetStats_chart_type: 'Tipo di grafico: linea o istogramma',
	streamTweetStats_chart_height: 'Altezza del grafico',
	streamTweetStats_chart_colors: 'Array di colori usati nel grafico',
	streamTweetStats_user_token : 'Usertoken, da utilizzare in caso di stream privati',

	/* styles */
	yucca_stream_tweet_stats : 'Pannello principale',
	yucca_stream_tweet_stats_header : 'Header',
	yucca_stream_tweet_stats_content : 'Body',
	yucca_stream_tweet_stats_chart : 'Pannello grafico',
	yucca_stream_tweet_stats_xaxis_label: 'Asse x',
	yucca_stream_tweet_stats_data : 'Pannello statistiche',
	yucca_stream_tweet_stats_table : 'Tabella statistiche',
	yucca_stream_tweet_stats_value : 'Valore statistica',
	yucca_stream_tweet_stats_label : 'Etichetta statistica',
	yucca_stream_tweet_stats_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	yucca_stream_tweet_stats_tooltip : 'Tooltip: pannello principale',
	yucca_stream_tweet_stats_tooltip_header : 'Tooltip: header',
	tweet_profile_image : 'Tooltip: Immagine profilo twitter',
	tweet_message : 'Tooltip: pannello tweet',
	tweet_author : 'Tooltip: autore',
	tweet_text : 'Tooltip: tweet',
	tweet_user : 'Tooltip: utente citato nel tweet',
	tweet_hashtag : 'Tooltip: hastag nel tweet',
	tweet_retweet : 'Tooltip: num retweet',
	tweet_favorite : 'Tooltip: num favorite',
	tweet_info : 'Tooltip: footer con info',
	tweet_statistic_icons : 'Tooltip: pannello con icone info',
	tweet_date : 'Tooltip: data del tweet',

	/* ************* */
	/* IMAGE GALLERY */
	/* ************* */
	datasetImageGallery_intro : '<p>Widget pensato per i dataset che contengono <strong>immagini</strong></p>'
			+ '<p>Si presenta come uno <strong>slideshow</strong> di immagini, dopo avere indicato la (o le) colonne desiderate.</p>'
			+ '<p>Se le immagini sono <strong>geolocalizzate</strong>, indicando le colonne con latitudine e longitudine, verr&grave; creato un secondo pannello contenente una mappa che riporta i luoghi delle immagini</p>',
	
	/* params */
	datasetImageGallery_widget_title : 'Titolo del widget',
	datasetImageGallery_widget_intro: 'Descrizione introduttiva',
	datasetImageGallery_tenant_code : 'Codice tenant del dataset',
	datasetImageGallery_dataset_code : 'Codice del dataset',
	datasetImageGallery_image_columns : 'Colonne del dataset che contengono le immagini da visualizzare',
	datasetImageGallery_image_title_column : 'Colonna del dataset con il titolo dell\'immagine',
	datasetImageGallery_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetImageGallery_position_columns : 'Colonne del dataset con le coordinate dell\'immagine. Se presenti viene visualizzata una mappa con le immagini',
	datasetImageGallery_filter : 'Filtro per selezionare le immagini da visualizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetImageGallery_skip : 'Numero immagine da cui iniziare l\'estrazione ',
	datasetImageGallery_top : 'Numero di immagini da estrarre (max 50)',
	datasetImageGallery_interval : 'Intervallo di tempo per lo slideshow (ms)',
	datasetImageGallery_show_title : 'Flag per visualizzare/nascondere il titolo dell\'immagine nello slideshow ',
	datasetImageGallery_marker_as_image : 'Visualizzare una miniatura dell\'immagine nella mappa',
	datasetImageGallery_marker_url : 'Marker da utilizzare',
	datasetImageGallery_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetImageGallery_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_dataset_image_gallery : 'Pannello principale',
	yucca_dataset_image_gallery_header : 'Header',
	yucca_dataset_image_gallery_content : 'Body',
	yucca_dataset_image_gallery_map : 'Mappa',
	yucca_dataset_image_gallery_slideshow : 'Slideshow',
	yucca_dataset_image_gallery_slide_title : 'Titolo immagine nello slideshow',
	yucca_dataset_image_gallery_bullets_panel : 'Pannello con bullet per lo slideshow',
	yucca_dataset_image_gallery_bullet : 'Singolo bullet nello slideshow',
	yucca_dataset_image_gallery_data : 'Pannello statistiche',
	yucca_dataset_image_gallery_total_count : 'Totale dati',
	yucca_dataset_image_gallery_toolbar : 'Toolbar con men&ugrave per cambio pannello da visualizzare',

	/* *************** */
	/* MULTIDATA STATS */
	/* *************** */
	datasetMultidataStats_intro : '<p>Widget pensato per visualizzare con un <strong>istogramma dati e statistiche</strong> relativi a dataset con colonne raggruppabili.</p>'
			+ '<p>Si possono indicare fino a tre gruppi di dati</p>'
			+ '<p>Si presenta con un istogramma con tante colonne quante sono le serie di dati indicati e un secondo pannello con una tabella navigabile contente i dati.</p>',
			
	/* params */
	datasetMultidataStats_widget_title : 'Titolo del widget',
	datasetMultidataStats_widget_intro: 'Descrizione introduttiva',
	datasetMultidataStats_tenant_code : 'Codice tenant del dataset',
	datasetMultidataStats_dataset_code : 'Codice del dataset',
	datasetMultidataStats_first_group_column : 'Colonna del dataset da cui fare il raggruppamento principale',
	datasetMultidataStats_first_group_colors : 'Colori da utilizzare nel grafico per distinguere la prima serie',
	datasetMultidataStats_histogram_group_column : 'Colonna da usare per per ottenere pi&ugrave; istogrammi raggruppando i valori della colonna indicata (un istogramma per occorrenza del valore). Da usare in alternativa al parametro \'second_group_column\'. ATTENZIONE: usando questo parametro le statistiche vengono effettuate solo sul conteggio, se si vuole sommare i valori &egrave; necessario indicare la colonna da sommare (parametro \'histogram_group_value_column\')',
	datasetMultidataStats_histogram_group_value_column : 'Colonna che indica i valori da sommare nel caso si sia specificato la creazione automatica degli istogrammi (parametro \'histogram_group_column\') e utilizzato il metodo conteggo \'somma\' (parametro \'counting_mode\')',
	datasetMultidataStats_second_group_column : 'Lista delle colonne per il secondo raggruppamento. Se omessa viene considerata solo la prima serie',
	datasetMultidataStats_second_group_label : 'Lista delle etichette da visualizzare per la seconda serie. Se omessa viene utilizzato la colonna stessa',
	datasetMultidataStats_third_group_column : 'Colonna del dataset per cui effettuare il terzo raggruppamento. Questo raggruppamento viene utilizzato solo nella tabella dei dati',
	datasetMultidataStats_counting_mode : 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori',
	datasetMultidataStats_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetMultidataStats_chart_height : 'Altezza del grafico',
	datasetMultidataStats_chart_type : 'Tipo di grafico: istogramma verticale o orizzontale',
	datasetMultidataStats_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetMultidataStats_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetMultidataStats_top : 'Numero di righe da estrarre',
	datasetMultidataStats_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetMultidataStats_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_dataset_multidata_stats : 'Pannello principale',
	yucca_dataset_multidata_stats_header : 'Header',
	yucca_dataset_multidata_stats_content : 'Body',
	yucca_dataset_multidata_stats_chart : 'Pannello grafico',
	yucca_dataset_multidata_stats_data : 'Pannello dati',
	yucca_dataset_multidata_stats_table : 'Tabella dati',
	yucca_dataset_multidata_stats_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	yucca_dataset_multidata_stats_tooltip : 'Tooltip: pannello principale',
	yucca_dataset_multidata_stats_tooltip_header : 'Tooltip: header',
	yucca_dataset_multidata_stats_tooltip_label : 'Tooltip: etichetta nella tabella',
	yucca_dataset_multidata_stats_tooltip_value : 'Tooltip: valore nella tabella',

	/* *************** */
	/* MULTISTREAM VALUE */
	/* *************** */
	streamMultistreamValue_intro : '<p>Widget pensato per visualizzare <strong>l\'ultimo valore</strong> relativi ai componenti di uno o pi&ugrave stream</p>'
			+ '<p>Per ogni componente verr&agrave; visualizzato un <strong>semaforo che indica il livello di guardia dei valori</strong></p>'
			+ '<p>Il widget si connette tramite <strong>Web Socket</strong>, con aggiornamento  automatico  all\'arrivo di un nuovo valore, senza bisogno di ricaricare la pagina</p>',
			
	/* params */
	streamMultistreamValue_widget_title : 'Titolo del widget',
	streamMultistreamValue_widget_intro: 'Descrizione introduttiva',
	streamMultistreamValue_streams : '<p class="text-left" style="font-size: 11px">Array javascript che indica gli stream da ascoltare. <br>Ogni elemento dell\array &egrave; un oggetto javascript con queste propriet&agrave;:</p>'
			+ '<ul class="text-left"><li><strong>tenantCode</strong>: codice tenant dello stream</li>'
			+ '<li><strong>streamCode</strong>: codice stream</li>'
			+ '<li><strong>smartobjectCode</strong>: codice smartobject dello stream</li>'
			+ '<li><strong>components</strong>: Array con i componenti da visualizzare</li></ul>'
			+ '<p class="text-left">Ogni componente &egrave; a sua volta un oggetto con queste propriet&agrave;:</p>'
			+ '<ul  class="text-left"><li><strong>name</strong>: nome del componente </li>'
			+ '<li><strong>minWarning</strong>: soglia minima sotto la quale il semaforo diventa giallo (livello di warning)</li>'
			+ '<li><strong>minCritical</strong>: soglia minima sotto la quale il semaforo diventa rosso (livello critico)</li>'
			+ '<li><strong>maxWarning</strong>: soglia massima oltre la quale il semaforo diventa giallo (livello di warning)</li>'
			+ '<li><strong>maxCritical</strong>: soglia massima oltre la quale il semaforo diventa rosso (livello critico)</li></ul>'
			+ '<p class="text-left">Esempio di oggetto stream</p>'
			+ '<pre  style="font-size: 12px!important;" class="text-left"><code  style="width:100%; font-size: 12px;">[<br>&nbsp;{"tenantCode":"csp",<br>&nbsp;&nbsp;"streamCode":"H",<br>&nbsp;&nbsp;"smartobjectCode":"a3de712d-6801-5cc4-84b...",<br>&nbsp;&nbsp;"components":'
			+ '[<br>&nbsp;&nbsp;&nbsp;&nbsp;{"name":"value",<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"minWarning":"10",<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"minCritical":"0",<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"maxWarning":"30",<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"maxCritical":"50"<br>&nbsp;&nbsp;&nbsp;&nbsp;},<br>&nbsp;&nbsp;&nbsp;&nbsp;...<br>&nbsp;&nbsp;]<br>&nbsp;},<br>...<br>]'
			+ '</code></pre>',
	streamMultistreamValue_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	streamMultistreamValue_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_stream_multistream_value : 'Pannello principale',
	yucca_stream_multistream_value_header : 'Header',
	yucca_stream_multistream_value_content : 'Body',
	yucca_stream_multistream_value_data : 'Pannello dati',
	yucca_stream_multistream_value_table : 'Tabella dati',
	yucca_stream_multistream_value_stream_row : 'Riga che contiene il nome dello stream',
	yucca_stream_multistream_value_component : 'Riga che contiene i dati di un componente',
	yucca_stream_multistream_value_component_bullet : 'Pannello contenente il semaforo',
	bullet_ok : 'Classe del semaforo verde',
	bullet_warning : 'Classe del semaforo giallo',
	bullet_critical : 'Classe del semaforo rosso',
	yucca_stream_multistream_value_component_value : 'Pannello contenente il valore del dato',
	yucca_stream_multistream_component_measureunit : 'Pannello contenente l\'unit&agrave; di misura',
	yucca_stream_multistream_value_lastupdate_bar : 'Pannello contenente la data ultimo aggiornamento',
	
	/* *************** */
	/* LAST VALUE */
	/* *************** */
	streamLastValue_intro: '<p>Widget pensato per visualizzare <strong>l\'ultimo valore</strong> relativi a uno o  pi&ugrave; compoenti di uno stream</p>'
		+ '<p>Ogni pannello che ha una classe css unica, che permette di <strong>personalizzare</strong> ogni singolo componente (o eventualmente di nasconderlo)</p>',
		
	/* params */
	streamLastValue_widget_title : 'Titolo del widget, se omesso non viene visualizzato l\'header per dare maggiorre compattezza al widget',
	streamLastValue_widget_intro: 'Descrizione introduttiva',
	streamLastValue_tenant_code : 'Codice tenant dello stream',
	streamLastValue_stream_code : 'Codice dello stream',
	streamLastValue_smartobject_code : 'Codice dello Smartobject',
	streamLastValue_show_lastupdate : 'Flag che indica se visualizzare la data di aggiornamento. La data &egrave; comunque indicata in un tooltip sul valore del dato',
	streamLastValue_labels: 'Array contenente le etichette da visualizzare per ogni componente, in alternativa al nome componente. La dimensione dell\'array deve essere la stessa del numero di componenti visualizzati.',
	streamLastValue_components: 'Array contenente i nomi dei componenti dello stream che si vogliono visualizzare. Se non si indica nulla, vengono visualizzati tutti',
	streamLastValue_chart_type: 'Tipo di grafico: linea o istogramma',
	streamLastValue_chart_height: 'Altezza del grafico',
	streamLastValue_chart_width: 'Larghezza del grafico',
	streamLastValue_chart_color: 'Colore usato nel grafico',
	streamLastValue_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	streamLastValue_debug : 'Visualizzare le informazioni di debug',
		
	/* styles */
	yucca_stream_last_value: 'Pannello principale',
	yucca_stream_last_value_header: 'Header (default nascosto)',
	yucca_stream_last_value_content: 'Body',
	yucca_stream_last_value_data: 'Pannello contenitore dati',
	yucca_stream_last_value_panel: 'Pannello singolo componente',
	yucca_stream_last_value_panel_single: 'Pannello specifico del componente, classe creata dinamicamente partendo da name del componente',
	yucca_stream_last_value_panel_separator: 'Pannello che separa i singoli componenti (visibile solo se ci sono pi&ugrave; componenti)',
	yucca_stream_last_value_component_name: 'Pannello contenente il nome del componente',
	yucca_stream_last_value_component_panel: 'Pannello contenente il valore del dato',
	yucca_stream_last_value_component_value: 'Valore del dato ',
	yucca_stream_last_value_component_value_info: 'Pannello contenente le informazioni realtive al dato: trend di crescita e unit&agrave; di misura',
	yucca_stream_last_value_component_trend: 'Pannello contenente il trend di crescita: a seconda del trend sono poi associate tre ulteriori classi: \'trend_up\' se il dato cresce, ' +
	'\'trend_down\' se il dato decresce, \'trend_stable\' se il dato &egrave; stabile',
	yucca_stream_last_value_component_chart: 'Pannello contenente il grafico dell\'andamento del dati',
	yucca_stream_last_value_component_chart_x_xAxis: 'Asse X del grafico: vengono visualizzati solo il primo e ultimo valore a cui sono associate rispettivamente le classi \'min_value\' e \'max_value\'. '+
	'Il valore indicato &egrave; una data che &egrave; suddivisa in ora e giorno, a cui sono associate rispettivamente le classi \'value_hour\' e \'value_date\'',
	yucca_stream_last_component_measureunit: 'Pannello contenente l\'unit&agrave; di misura',
	yucca_stream_last_value_lastupdate_bar: 'Pannello contenente la data ultimo aggiornamento (default nascosto)',
	
	
	/* *************** */
	/* STREAM MONITOR */
	/* *************** */
	streamMonitor_intro: '<p>Widget pensato per visualizzare <strong>l\'andamento in tempo reale </strong> di a uno o  pi&ugrave; componenti di uno stream</p>'
		+ '<p>Si presenta con un pannello con il grafico e un pannello con una tabella contenente i dati</p>',

	/* params */
	streamMonitor_widget_title : 'Titolo del widget',
	streamMonitor_widget_intro: 'Descrizione introduttiva',
	streamMonitor_tenant_code : 'Codice tenant dello stream',
	streamMonitor_stream_code : 'Codice dello stream',
	streamMonitor_smartobject_code : 'Codice dello Smartobject',
	streamMonitor_components: 'Array contenente i nomi dei componenti dello stream che si vogliono visualizzare. Se non si indica nulla, vengono visualizzati tutti',
	streamMonitor_labels: 'Array contenente le etichette da visualizzare per ogni componente, in alternativa al nome componente. La dimensione dell\'array deve essere la stessa del numero di componenti.',
	streamMonitor_show_lastupdate : 'Flag che indica se visualizzare la data di aggiornamento. La data &egrave; comunque indicata in un tooltip sul valore del dato',
	streamMonitor_chart_type: 'Tipo di grafico: linea o istogramma',
	streamMonitor_landing_panel: 'Pannello visualizzato al caricamento del widget',
	streamMonitor_chart_height: 'Altezza del grafico',
	streamMonitor_chart_width: 'Larghezza del grafico',
	streamMonitor_chart_colors: 'Colori usati nel grafico',
	streamMonitor_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	streamMonitor_debug : 'Visualizzare le informazioni di debug',
		
	/* styles */
	yucca_stream_monitor: 'Pannello principale',
	yucca_stream_monitor_header: 'Header (default nascosto)',
	yucca_stream_monitor_content: 'Body',
	yucca_stream_monitor_chart: 'Pannello contenitore del grafico',
	yucca_stream_monitor_component_chart: 'Pannello contenente il grafico dell\'andamento del dati',
	yucca_stream_monitor_component_chart_x_xAxis: 'Asse X del grafico: vengono visualizzati solo il primo e ultimo valore a cui sono associate rispettivamente le classi \'min_value\' e \'max_value\'. '+
	'Il valore indicato &egrave; una data che &egrave; suddivisa in ora e giorno, a cui sono associate rispettivamente le classi \'value_hour\' e \'value_date\'',
	yucca_stream_monitor_data: 'Pannello contenitore dati',
	yucca_stream_monitor_table: 'Tabella contentente i dati',
	yucca_stream_monitor_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	yucca_stream_monitor_lastupdate_bar: 'Pannello contenente la data ultimo aggiornamento (default nascosto)',
	
	/* *********************** */
	/* MULTI STREAM   STATS    */
	/* *********************** */
	
	streamMultistreamStats_intro: '<p>Widget pensato per una visualizzare sulla mappa l\'andamento di uno o pi&ugrave; stream nel tempo.</p>' +
	'<p>Gli stream devono essere omogenei fra di loro, e avere i dati geolocalizzati, inoltre sotto la mappa &egrave; presente uno <strong>slider che permette di scorrere nel tempo</strong></p>'+
	'<p>&Egrave; possibile specificare un range temporale da analizzare (se non viene specificato si considera l\'ultimo giorno)</p>',
	
	/* params */
	streamMultistreamStats_widget_title: 'Titolo del widget, se omesso non viene visualizzato l\'header per dare maggiorre compattezza al widget',
	streamMultistreamStats_widget_intro: 'Descrizione introduttiva',
	streamMultistreamStats_datasets: 'Codici dei datasets',
	streamMultistreamStats_landing_panel: 'Pannello visualizzato al caricamento del widget',
	streamMultistreamStats_orderby: 'Clausola di ordinamento',
	streamMultistreamStats_user_token: 'Usertoken, da utilizzare in caso di stream privati',
	streamMultistreamStats_time_range: 'Intervallo di tempo su cui calcolare la statistica, in alternativa ai parametri di data minima  e data massima',
	streamMultistreamStats_time_min_date : 'Data iniziale dell\intervallo su cui calcolare la statistica',
	streamMultistreamStats_time_max_date : 'Data finale dell\intervallo su cui calcolare la statistica',
	streamMultistreamStats_top: 'Numero di righe da estrarre',

	/* styles */
	yucca_stream_multistream_stats: 'Widget Panel',
	yucca_stream_multistream_stats_header:'Widget Header',
	yucca_stream_multistream_stats_stream_name:'Stream Name',
	yucca_stream_multistream_stats_content:'Widget Content',
	yucca_stream_multistream_stats_chart:'Pannello contenente il grafico',
	yucca_stream_multistream_stats_data:'Pannello contenente i dati',
	yucca_stream_multistream_stats_table:'Tabella conentente i dati',
	yucca_stream_multistream_stats_component:'Stream Compent',
	yucca_stream_multistream_stats_component_key:'Stream Component measure key',
	yucca_stream_multistream_stats_component_value:'Stream Component measure value',
	yucca_stream_multistream_stats_component_measure_unit:'Stream Component measure unit',
	yucca_stream_multistream_stats_total_count:'Totale dati',
	yucca_stream_multistream_stats_toolbar:'Toolbar con men&ugrave per cambio pannello da visualizzare',
	
	/* *********************** */
	/* TREEMAP      */
	/* *********************** */
	
	datasetTreemap_intro : '<p>Widget pensato per visualizzare <strong>su una treemap</strong> i dati relativi a un dataset con colonne raggruppabili</p>'
		+ '<p>Sono previsti 3 livelli di navigazione nella treemap.</p>'
		+ '<p>Si presenta con un pannello contente una treemap composta da tanti rettangoli quanti sono i dati del primo livello. '
		+ 'Cliccando sui rettangoli si entra nel dettaglio del secondo livello, dove si pu&ograve; scendere ancora a un terzo livello. </p>'
		+ 'Nel dataset di esempio  c\'&egrave; la suddivisione per provincia, comune e giorno di mercato dei mercati urbani <ul><li>primo livello: la provincia</li>'
		+ '<li>secondo livello: giorno di mercato</li>'
		+ '<li>terzo livello: il comune</li>'
		+ '</ul>',
	/* params */
	datasetTreemap_widget_title : 'Titolo del widget',
	datasetTreemap_widget_intro: 'Descrizione introduttiva',
	datasetTreemap_tenant_code : 'Codice tenant del dataset',
	datasetTreemap_dataset_code : 'Codice del dataset',
	datasetTreemap_chart_title : 'Titolo principale del grafico',
	datasetTreemap_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetTreemap_first_level_column:'Colonna del dataset da cui raggruppare i dati per il primo livello',
	datasetTreemap_first_level_render:'<p class="text-left" style="font-size: 11px">Oggetto javascript che descrive come visualizzare i dati del primo livello.<br> '
			+ 'L\'oggetto ha una propriet&agrave; per ogni valore raggruppato, e a ogni propriet&agrave; &egrave; associato un oggetto che descrive l\'etichetta da usare e il colore. </p>'
			+ '<p class="text-left">Ad esempio se il dataset ha una colonna Provincia in cui sono presenti le sigle delle province, ma sul grafico si volesse il nome, l\'oggetto render &egrave;:</p>'
			+ '<pre  style="font-size: 12px!important;" class="text-left"><code  style="width:100%; font-size: 12px;">{<br>&nbsp;{"TO":{"label":"Torino", "color":"#ffee00"},<br>&nbsp;'
			+ ' "AT":{"label":"Asti", "color":"#67ff77"}<br>&nbsp;&nbsp; &hellip;<br>&nbsp;}<br>}'
			+ '</code></pre>',
	datasetTreemap_second_level_column:'Colonna del dataset da cui raggruppare i dati per il secondo livello',
	datasetTreemap_second_level_render:'<p class="text-left" style="font-size: 11px">Oggetto javascript che descrive come visualizzare i dati del secondo livello.<br> '
		+ 'L\'oggetto ha una propriet&agrave; per ogni valore raggruppato, e a ogni propriet&agrave; &egrave; associato un oggetto che descrive l\'etichetta da usare</p>'
		+ '<p class="text-left">Ad esempio se il dataset ha una colonna ISTAT in cui sono presenti i codici istat, ma sul grafico si volesse il nome del comune, l\'oggetto render &egrave;:</p>'
		+ '<pre  style="font-size: 12px!important;" class="text-left"><code  style="width:100%; font-size: 12px;">{<br>&nbsp;{"001272":{"label":"Torino"},<br>&nbsp;'
		+ ' "005005":{"label":"Asti"}<br>&nbsp;&nbsp; &hellip;<br>&nbsp;}<br>}'
		+ '</code></pre>',
	datasetTreemap_third_level_column:'Colonna del dataset da cui raggruppare i dati per il terzo livello',
	datasetTreemap_third_level_render:'<p class="text-left" style="font-size: 11px">Oggetto javascript che descrive come visualizzare i dati del terzo livello.<br> '
		+ 'L\'oggetto ha una propriet&agrave; per ogni valore raggruppato, e a ogni propriet&agrave; &egrave; associato un oggetto che descrive l\'etichetta da usare</p>'
		+ '<p class="text-left">Ad esempio se il dataset ha una colonna ISTAT in cui sono presenti i codici istat, ma sul grafico si volesse il nome del comune, l\'oggetto render &egrave;:</p>'
		+ '<pre  style="font-size: 12px!important;" class="text-left"><code  style="width:100%; font-size: 12px;">{<br>&nbsp;{"001272":{"label":"Torino"},<br>&nbsp;'
		+ ' "005005":{"label":"Asti"}<br>&nbsp;&nbsp; &hellip;<br>&nbsp;}<br>}'
		+ '</code></pre>',
	datasetTreemap_value_column:'Colonna del dataset da cui ricavare i valori da sommare o contare',
	datasetTreemap_euro_value:'Indica se il valore conteggiato &egrave; in euro (formatta adeguatamente i valori)',	
	datasetTreemap_decimal_value:'Numero di cifre da usare in caso di valori decimali (default 2)',	
	datasetTreemap_counting_mode : 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori',
	datasetTreemap_chart_width : 'Larghezza del grafico',
	datasetTreemap_chart_height : 'Altezza del grafico',
	datasetTreemap_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetTreemap_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetTreemap_top : 'Numero di righe da estrarre',
	datasetTreemap_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetTreemap_debug : 'Visualizzare le informazioni di debug',

	
	/* styles */
	yucca_dataset_treemap : 'Pannello principale',
	yucca_dataset_treemap_header : 'Header',
	yucca_dataset_treemap_content : 'Body',
	yucca_dataset_treemap_chart : 'Pannello del grafico',
	yucca_dataset_treemap_chart_message : 'Messaggi nel pannello del grafico visualizzati in fase di caricamento (loading&hellip;) o se non sono presenti dati',
	yucca_dataset_treemap_data : 'Pannello dati',
	yucca_dataset_treemap_table : 'Tabella dati',
	yucca_dataset_treemap_toolbar:'Toolbar con men&ugrave per cambio pannello da visualizzare',
	legend: 'Pannello contenente la legenda del grafico. Contenuto in un pannello con id <strong>treemapPanel</strong>',
	legend_label: 'Etichetta con valore minimo e massimo nella legenda. Contenuto in un pannello con id <strong>treemapPanel</strong>', 
	legend_bullet: 'Box con colore della legenda. Contenuto in un pannello con id <strong>treemapPanel</strong>',

	/* *********************** */
	/* MULTI DATA TREEMAP      */
	/* *********************** */
	
	datasetMultidataTreemap_intro : '<p>Widget pensato per visualizzare <strong>su una treemap</strong> i dati relativi a dataset con dati raggruppabili suddivisi su pi&ugrave; colonne</p>'
		+ '<p>Sono previsti 3 livelli di navigazione nella treemap pi&ugrave; un (opzionale) valore realtivo a una percentuale sull\'ultimo livello.</p>'
		+ '<p>Si presenta con un pannello contente una treemap composta da tanti rettangoli quanti sono i dati del primo livello. '
		+ 'Cliccando sui rettangoli si entra nel dettaglio del secondo livello, dove si pu&ograve; scendere ancora a un terzo livello. Il valore percentuale (eventuale) viene visualizzato tramite la luminosit&agrave; dei rettangoli al terzo livello.</p>'
		+ 'Nel dataset di esempio  c\'&egrave; la suddivisione per comune del riciclo dei rifiuti urbani <ul><li>primo livello: tipo di rifiuto (vetro, carta &hellip;)</li>'
		+ '<li>secondo livello: quantit&agrave; suddivisa per provincia</li>'
		+ '<li>terzo livello: quantit&agrave; suddivisa per comune</li>'
		+ '<li>quarto livello: percentuale di riciclo per comune</li></ul>',
	/* params */
	datasetMultidataTreemap_widget_title : 'Titolo del widget',
	datasetMultidataTreemap_widget_intro: 'Descrizione introduttiva',
	datasetMultidataTreemap_tenant_code : 'Codice tenant del dataset',
	datasetMultidataTreemap_dataset_code : 'Codice del dataset',
	datasetMultidataTreemap_chart_title : 'Titolo principale del grafico',
	datasetMultidataTreemap_euro_value:'Indica se il valore conteggiato &egrave; in euro (formatta adeguatamente i valori)',	
	datasetMultidataTreemap_decimal_value:'Numero di cifre da usare in caso di valori decimali (default 2)',	
	datasetMultidataTreemap_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetMultidataTreemap_first_group_column : 'Lista delle colonne del dataset da cui fare il raggruppamento principale',
	datasetMultidataTreemap_colors : 'Colori da utilizzare nel grafico per distinguere la prima serie',
	datasetMultidataTreemap_first_group_label : 'Lista delle etichette da visualizzare per la seconda serie. Se omessa viene utilizzato la colonna stessa',
	datasetMultidataTreemap_second_group_column : 'Colonna del dataset per il secondo raggruppamento',
	datasetMultidataTreemap_third_group_column : 'Colonna del dataset per cui effettuare il terzo raggruppamento',
	datasetMultidataTreemap_fourth_group_column : 'Colonna indicate il valore in percentuale da rappresentare nell\'ultimo livello',
	datasetMultidataTreemap_counting_mode : 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori',
	datasetMultidataTreemap_chart_width : 'Larghezza del grafico',
	datasetMultidataTreemap_chart_height : 'Altezza del grafico',
	datasetMultidataTreemap_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetMultidataTreemap_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetMultidataTreemap_top : 'Numero di righe da estrarre',
	datasetMultidataTreemap_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetMultidataTreemap_debug : 'Visualizzare le informazioni di debug',


	
	
	/* styles */
	yucca_dataset_multidata_treemap : 'Pannello principale',
	yucca_dataset_multidata_treemap_header : 'Header',
	yucca_dataset_multidata_treemap_content : 'Body',
	yucca_dataset_multidata_treemap_chart : 'Pannello del grafico',
	yucca_dataset_multidata_treemap_chart_message : 'Messaggi nel pannello del grafico visualizzati in fase di caricamento (loading&hellip;) o se non sono presenti dati',
	yucca_dataset_multidata_treemap_data : 'Pannello dati',
	yucca_dataset_multidata_treemap_table : 'Tabella dati',
	yucca_dataset_multidata_treemap_toolbar:'Toolbar con men&ugrave per cambio pannello da visualizzare',
	legend: 'Pannello contenente la legenda del grafico. Contenuto in un pannello con id <strong>treemapPanel</strong>',
	legend_label: 'Etichetta con valore minimo e massimo nella legenda. Contenuto in un pannello con id <strong>treemapPanel</strong>', 
	legend_bullet: 'Box con colore della legenda. Contenuto in un pannello con id <strong>treemapPanel</strong>',
	
	/* *************** */
	/* MULTIDATA STATS */
	/* *************** */
	datasetMultidataStats_intro : '<p>Widget pensato per visualizzare con un <strong>istogramma dati e statistiche</strong> relativi a dataset con colonne raggruppabili.</p>'
			+ '<p>Si possono indicare fino a tre gruppi di dati</p>'
			+ '<p>Si presenta con un istogramma con tante colonne quante sono le serie di dati indicati e un secondo pannello con una tabella navigabile contente i dati.</p>',
			
			
			

	/* params */
	datasetMultidataStats_widget_title : 'Titolo del widget',
	datasetMultidataStats_widget_intro: 'Descrizione introduttiva',
	datasetMultidataStats_tenant_code : 'Codice tenant del dataset',
	datasetMultidataStats_dataset_code : 'Codice del dataset',
	datasetMultidataStats_first_group_column : 'Colonna del dataset da cui fare il raggruppamento principale',
	datasetMultidataStats_first_group_colors : 'Colori da utilizzare nel grafico per distinguere la prima serie',
	datasetMultidataStats_second_group_column : 'Lista delle colonne per il secondo raggruppamento. Se omessa viene considerata solo la prima serie',
	datasetMultidataStats_second_group_label : 'Lista delle etichette da visualizzare per la seconda serie. Se omessa viene utilizzato la colonna stessa',
	datasetMultidataStats_third_group_column : 'Colonna del dataset per cui effettuare il terzo raggruppamento. Questo raggruppamento viene utilizzato solo nella tabella dei dati',
	datasetMultidataStats_counting_mode : 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori',
	datasetMultidataStats_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetMultidataStats_chart_height : 'Altezza del grafico',
	datasetMultidataStats_chart_type : 'Tipo di grafico: istogramma verticale o orizzontale',
	datasetMultidataStats_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetMultidataStats_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetMultidataStats_top : 'Numero di righe da estrarre',
	datasetMultidataStats_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetMultidataStats_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_dataset_multidata_stats : 'Pannello principale',
	yucca_dataset_multidata_stats_header : 'Header',
	yucca_dataset_multidata_stats_content : 'Body',
	yucca_dataset_multidata_stats_chart : 'Pannello grafico',
	yucca_dataset_multidata_stats_data : 'Pannello dati',
	yucca_dataset_multidata_stats_table : 'Tabella dati',
	yucca_dataset_multidata_stats_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	yucca_dataset_multidata_stats_tooltip : 'Tooltip: pannello principale',
	yucca_dataset_multidata_stats_tooltip_header : 'Tooltip: header',
	yucca_dataset_multidata_stats_tooltip_label : 'Tooltip: etichetta nella tabella',
	yucca_dataset_multidata_stats_tooltip_value : 'Tooltip: valore nella tabella',

	/* ******************** */
	/* DATASET BULLET CHART */
	/* ******************** */
	datasetBulletChart_intro : '<p>Widget pensato per visualizzare uno o pi&ugrave; <strong>bullet chart</strong> relativi a <strong>singoli</strong> dati di un dataset</p>'
			+ '<p>Si possono specificare uno o pi&ugrave; dati su cui creare il grafico, indicando la colonna da prendere in cosiderazione per visualizzare il valore corrente.</p>'
			+ '<p>&Egrave; possibile <strong>specificare il range</strong> da visualizzare (valore minimo, valore massimo e valore medio), o lasciare che questi valori siano <strong>calcolati</strong> dal widget utilizzando i primi 10.000 record</p>'
			+ '<p>&Egrave; possibile indicare <strong>altri marker</strong> da inserire sulla barra indicatrice, con le relative etichette</p>',
			
	/* params */
	datasetBulletChart_widget_title : 'Titolo del widget',
	datasetBulletChart_widget_intro: 'Descrizione introduttiva',
	datasetBulletChart_tenant_code: 'Codice tenant del dataset',
	datasetBulletChart_dataset_code: 'Codice del dataset',
	datasetBulletChart_internal_ids: 'Internal ID dei dataset da considerare.',
	datasetBulletChart_filter_ids: 'Filtro OData per effetture una query e ricavare i singoli dati su cui disegnare il grafico. Ogni dato ha un suo grafico. La query &egrave; limitata a un massimo di 50 record. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetBulletChart_current_value_column: 'Colonna indicante il valore da visualizzare',
	datasetBulletChart_range_values: 'Array con i range: valore minimo, valore medio e valore massimo. Se non specificato e non specificato l\'array delle colonne (parametro successivo), vengono calcolati fra i primi 10.000 dati del dataset',
	datasetBulletChart_range_column_values: 'Array con le colonne da cui recuperare i valori dei range: colonna per valore minimo, colonna per valore medio e colonna per valore massimo.  Se non specificato e non specificato l\'array dei valori (parametro precedente), vengono calcolati fra i primi 10.000 dati del dataset',
	datasetBulletChart_bar_title_column: 'Colonna del dataset da cui prendere l\'etichetta per il titolo della barra',
	datasetBulletChart_bar_subtitle_colum: 'Colonna del dataset da cui prendere l\'etichetta per il sottotitolo della barra',
	datasetBulletChart_filter : 'Filtro per selezionare i dati da analizzare, si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetBulletChart_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetBulletChart_top : 'Numero di righe da estrarre',	
	datasetBulletChart_euro_value:'Indica se il valore conteggiato &egrave; in euro (formatta adeguatamente i valori)',	
	datasetBulletChart_decimal_value:'Numero di cifre da usare in caso di valori decimali (default 2)',	
	datasetBulletChart_previous_value_column: 'Colonna indicante il valore precedente da visualizzare',
	datasetBulletChart_bar_colors: 'Lista dei colori da usare per i bullet chart. I colori vengono usati uno per grafico ciclicamente',
	datasetBulletChart_bar_title_label: 'Etichetta per il titolo della barra (da usare in alternativa a datasetBulletChart_bar_title_column)',
	datasetBulletChart_bar_subtitle_label: 'Etichetta per il sottotitolo della barra (da usare in alternativa a datasetBulletChart_bar_subtitle_colum)',
	datasetBulletChart_average_values: 'Effettua la media dei valori, restituendo un unico bullet chart. <strong>Se specificati gli Internal ID (paramentro \'internal_ids\'), la media NON viene calcolata, ma viene creato un bullet chart per ogni dato</strong>',
	datasetBulletChart_range_labels: 'Etichetta da utilizzare nel tooltip per indicare il valore minimo, massimo e medio. Default: Minumum, Mean, Maximun',
	datasetBulletChart_measure_labels: 'Etichetta da utilizzare nel tooltip per indicare il valore corrente. Default: Current',
	datasetBulletChart_custom_markers: 'Lista di valori per ulteriori marker da inserire sulla barra',
	datasetBulletChart_custom_marker_columns: 'Colonne i cui valori verranno visualizzati come marker',
	datasetBulletChart_marker_labels: 'Etichette relative ai marker aggiuntivi',
	datasetBulletChart_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetBulletChart_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_dataset_bullet_chart : 'Pannello principale',
	yucca_dataset_bullet_chart_header : 'Header',
	yucca_dataset_bullet_chart_content : 'Body',
	yucca_dataset_bullet_chart_chart : 'Pannello del grafico',
	yucca_dataset_bullet_chart_tooltip : 'Pannello del tooltip',

	
	/* ******************** */
	/* DATASET SANKEY CHART */
	/* ******************** */
	datasetSankeyChart_intro: '<p>Widget pensato per visualizzare un diagramma di Sankey realtivamente ai dati di un dataset</p>'
		+ '<p>Si possono <strong>specificare due o pi&ugrave; colonne</strong> e il widget <strong>calcola in automatico</strong> i link fra di esse, rispettando l\'ordine di inserimento.</p>'
		+ '<p>&Egrave; possibile <strong>specificare direttamente i nodi e link</strong> con cui creare il diagramma, in questo caso la piattaforma Yucca non viene contattata, e i dati visualizzati sono esclusivamente quelli in input</p>',

	/* params */
	datasetSankeyChart_widget_title : 'Titolo del widget',
	datasetSankeyChart_widget_intro: 'Descrizione introduttiva',
	datasetSankeyChart_tenant_code: 'Codice tenant del dataset',
	datasetSankeyChart_dataset_code: 'Codice del dataset',

	datasetSankeyChart_node_columns: 'Colonne da considerare nel calcolo automatico dei nodi',
	datasetSankeyChart_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetSankeyChart_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetSankeyChart_top : 'Numero di righe da estrarre',	
	datasetSankeyChart_chart_width: 'Larghezza del grafico in pixel (default 600px)',
	datasetSankeyChart_chart_height: 'Altezza del grafico in pixel (default 400px)',
	datasetSankeyChart_sankey_nodes: 'Nodi da usare, se specificato insieme ai link (parametro successivo),la piattaforma yucca non viene contattata e vengono visualizzati nodi e link indicati. <a href="./sankeyDemoData.json" target="_blank">Esempio di formattazione dei nodi/link</a>',
	datasetSankeyChart_sankey_links: 'Link da usare, se specificato insieme ai nodi (parametro precedente),la piattaforma yucca non viene contattata e vengono visualizzati nodi e link indicati. <a href="./sankeyDemoData.json" target="_blank">Esempio di formattazione dei nodi/link</a>',
	datasetSankeyChart_sankey_node_render:'<p class="text-left" style="font-size: 11px">Oggetto javascript che descrive come visualizzare i nodi.<br> '
	+ 'L\'oggetto ha una propriet&agrave; con chiave <i>nome_colonna_valore_nodo</i> a cui &egrave; associato un oggetto che descrive l\'etichetta da usare e il colore, e se sfumare il colore (fader). </p>'
	+ '<p class="text-left">Ad esempio se il dataset ha una colonna Provincia in cui sono presenti le sigle delle province, ma sul grafico si volesse il nome, l\'oggetto render &egrave;:</p>'
	+ '<pre  style="font-size: 12px!important;" class="text-left"><code  style="width:100%; font-size: 12px;">{<br>&nbsp;{"Prov_TO":{"label":"Torino", "color":"#ffee00", "fader": "true"},<br>&nbsp;'
	+ ' "Prov_AT":{"label":"Asti", "color":"#67ff77", "fader": "true"}<br>&nbsp;&nbsp; &hellip;<br>&nbsp;}<br>}'
	+ '</code></pre>', 
	datasetSankeyChart_base_color: 'Colore base da usare per i nodi quando non viene specificato il colore nel render', 
	datasetSankeyChart_counting_mode: 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori', 
	datasetSankeyChart_value_column:'Colonna del dataset da cui ricavare i valori da sommare o contare', 
	datasetSankeyChart_euro_value:'Indica se il valore conteggiato &egrave; in euro (formatta adeguatamente i valori)' ,
	datasetSankeyChart_decimal_value:'Numero di cifre da usare in caso di valori decimali (default 2)',	
	datasetSankeyChart_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetSankeyChart_debug : 'Visualizzare le informazioni di debug',

	/* styles */
	yucca_dataset_sankey : 'Pannello principale',
	yucca_dataset_sankey_header : 'Header',
	yucca_dataset_sankey_loading : 'Pannello loading',
	yucca_dataset_sankey_content : 'Body',
	yucca_dataset_sankey_chart: 'Pannello del grafico',

	
	/* ****************** */
	/* POULATION PYRAMID  */
	/* ****************** */
	datasetPopulationPyramid_intro : '<p>Widget pensato per visualizzare una <strong>piramide della popolazione</strong> relativi a dataset i cui dati siano suddivisibili in 2 gruppi (maschi e femmine), e raggruppabili per un\'altra colonna (le et&agrave;).</p>'
			+ '<p>Si presenta con due istogrammi orizzontali disposti in maniera speculare e un secondo pannello con una tabella navigabile contente i dati.</p>',
			
	/* params */
	datasetPopulationPyramid_widget_title : 'Titolo del widget',
	datasetPopulationPyramid_widget_intro: 'Descrizione introduttiva',
	datasetPopulationPyramid_tenant_code : 'Codice tenant del dataset',
	datasetPopulationPyramid_dataset_code : 'Codice del dataset',
	datasetPopulationPyramid_gender_column : 'Colonna del dataset in cui &egrave; indicato il genere (maschio o femmina), in generale colonna in cui ci sono i due valori su cui fare i due istogrammi speculari',
	datasetPopulationPyramid_age_column : 'Colonna del dataset in cui vengono indicate le fasce di et&agrave;, in generale colonna in cui ci sono i valori da raggruppare',
	datasetPopulationPyramid_age_values: 'Valori da prendere in considerazione per la suddivisione in fasce di et&agrave;. Utile nel caso si vogliano solo considerare alcune fasce, o si voglia avere un ordinamento delle fasce',
	datasetPopulationPyramid_gender_values : 'Valori usati per distinguere il genere (default M, F), in generale valori usati per distinguere i dati per i due istogrammi speculari',
	datasetPopulationPyramid_gender_colors : 'Colori usati per i due istogrammi speculari (default rosa e azzurro)',
	datasetPopulationPyramid_gender_labels : 'Etichette usate per i due istogrammi speculari (default F e M)',
	datasetPopulationPyramid_age_labels : 'Etichette usate per le fasce di et&agrave; (default i valori trovati)',
	datasetPopulationPyramid_counting_mode : 'Metodo di calcolo delle statistiche: \'count\'conta le occorrenze, \'sum\' somma i valori nella colonna specificata dal parametro \'value_column\'',
	datasetPopulationPyramid_value_column:'Colonna contenente i valori da sommare se il tipo di conteggio &egrave; di tipo somma (parametro counting_mode = \'sum\')',
	datasetPopulationPyramid_landing_panel: 'Pannello visualizzato al caricamento del widget',
	datasetPopulationPyramid_chart_height : 'Altezza del grafico',
	datasetPopulationPyramid_chart_type : 'Tipo di grafico: istogramma verticale o orizzontale',
	datasetPopulationPyramid_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetPopulationPyramid_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetPopulationPyramid_top : 'Numero di righe da estrarre',
	datasetPopulationPyramid_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetPopulationPyramid_debug : 'Visualizzare le informazioni di debug',

	
	/* styles */
	yucca_dataset_population_pyramid : 'Pannello principale',
	yucca_dataset_population_pyramid_header : 'Header',
	yucca_dataset_population_pyramid_content : 'Body',
	yucca_dataset_population_pyramid_chart : 'Pannello grafico',
	yucca_dataset_population_pyramid_data : 'Pannello dati',
	yucca_dataset_population_pyramid_table : 'Tabella dati',
	yucca_dataset_population_pyramid_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	yucca_dataset_population_pyramid_tooltip : 'Tooltip: pannello principale',
	yucca_dataset_population_pyramid_tooltip_header : 'Tooltip: header',
	yucca_dataset_population_pyramid_tooltip_label : 'Tooltip: etichetta nella tabella',
	yucca_dataset_population_pyramid_tooltip_value : 'Tooltip: valore nella tabella',
	
	
	/* ****************** */
	/* CHOROPLETH MAP  */
	/* ****************** */
	datasetChoroplethMap_intro : '<p>Widget pensato per visualizzare una <strong>Mappa coropletica</strong> relativa a un dataset contenente il risultato di calcoli statistici suddivisi per aree (es densit&agrave; popolazione per province).</p>'
			+ '<p>Le aree della mappa devono essere disponibili a una url raggiungibile, in formato <strong>GeoJson</strong>. Il widget mette a disposizione le aree relative alle province del Piemonte</p>'
			+'<p>Nelle features del file GeoJson delle aree, deve essere presente una properties che identifica l\'area (es provincia:Torino), che deve corrispondere al valore di una delle colonne del dataset (esempio nel dataset ci sar&agrave; una colonna chiamata provincia che avr&agrave; al suo interno un dato con valore Torino).</p>'
			+'<p>Nella configurazione si dovr&agrave; indicare il nome della colonna relativa alla chiave dell\'area e il nome della colonna relativa al valore da rappresentare (la densit&agrave;)</p>'
			+'<p>Tramite parametri di configurazione &egrave; possibile <strong>personalizzare la mappa nei colori, nelle linee nello sfondo</strong></p>',
			
	/* params */
	datasetChoroplethMap_widget_title : 'Titolo del widget',
	datasetChoroplethMap_widget_intro: 'Descrizione introduttiva',
	datasetChoroplethMap_tenant_code : 'Codice tenant del dataset',
	datasetChoroplethMap_dataset_code : 'Codice del dataset',
	datasetChoroplethMap_geojson_url:'Url del file GeoJson da utilizzare (se non specificato verranno usate le province del Piemonte)',
	datasetChoroplethMap_geojson_areas_key:'Chiave per identificare le aree all\interno del file GeoJson. Il valore delle chiavi dovr&agrave; corrispondere a quello presente nel dataset',
	datasetChoroplethMap_dataset_areas_key_column:'Colonna del dataset  al cui interno c\'&egrave; il dato per identificare l\area sulla mappa. Il valore dovr&agrave; corrispondere a quello presente nel file GeoJson',
	datasetChoroplethMap_dataset_areas_value_column:'Colonna del dataset con il dato da rappresentare sulla mappa',
	datasetChoroplethMap_area_base_color:'Colore di base della mappa. I valori modificando la luminosit&agrave;',
	datasetChoroplethMap_skip_zero_values:'Flag per indicare se nel calcolo dei colori, si devono escludere i dati con valore zero (che verranno rappresentati in grigio sulla mappa)',
	datasetChoroplethMap_counting_mode : 'Metodo di calcolo delle statistiche: se i dati della seconda serie sono numerici, si possono sommare indicando \'sum\', in alternativa vengono contati i valori',
	datasetChoroplethMap_show_legend:'Flag per indicare se visualizzare la legenda',
	datasetChoroplethMap_euro_value :'Indica se il valore conteggiato &egrave; in euro (formatta adeguatamente i valori)',
	datasetChoroplethMap_decimal_value:'numero di cifre da usare in caso di valori decimali (default 2)',	
	datasetChoroplethMap_zoom_control:'Flag per indicare se visualizzare i controlli per lo zoom',
	datasetChoroplethMap_scroll_wheel_zoom:'Flag per indicare effettuare lo zoom tramite la rotella del mouse',
	datasetChoroplethMap_legend_position:'Posizione della legenda',
	datasetChoroplethMap_map_tiles_url:'Url delle tiles (grafica) da utilizzare sulla mappa. Se si indica una url non valida la mappa resta grigia, ma le aree colorate vengono visualizzate ugualmente',
	datasetChoroplethMap_map_line_weight:'Spessore della riga che separa le aree (confini)',
	datasetChoroplethMap_map_line_opacity:'Trasparenza della riga che separa le aree (confini)',
	datasetChoroplethMap_map_line_dash_color:'Colore della riga che separa le aree (confini)',
	datasetChoroplethMap_map_line_dash_array:'Livello di tratteggio della riga che separa le aree (confini)',
	datasetChoroplethMap_map_areas_fill_opacity:'Trasparenza del colore sull\'area',
	datasetChoroplethMap_filter : 'Filtro per selezionare i dati da analizzare. Si utilizza il formato OData: sono validi gli operatori \'eq, ne, gt, ge, lt, le, and, or\'. Esempio: nome_colonna eq valore_dato',
	datasetChoroplethMap_dataset_areas_key_label: 'Etichetta da utilizzare per visualizzare la chiave nel tooltip',
	datasetChoroplethMap_dataset_areas_values_label: 'Etichetta da utilizzare per visualizzare il dato nel tooltip ',
	datasetChoroplethMap_skip : 'Numero riga da cui iniziare l\'estrazione ',
	datasetChoroplethMap_top : 'Numero di righe da estrarre',
	datasetChoroplethMap_user_token : 'Usertoken, da utilizzare in caso di stream privati',
	datasetChoroplethMap_debug : 'Visualizzare le informazioni di debug',
	
	
	/* Discretebar Chart */
	basicDatasetDiscretebarChart: 'Grafico a barre', 
	
	help_intro_basicDatasetDiscretebarChart: 'Con questo widget si rappresenta la distribuzione in classi di un carattere continuo',
	help_datasource_basicDatasetDiscretebarChart: 'Il widget si aspetta un dataset che abbia una colonna su cui raggruppare i dati che sar&agrave; rappresentata' + 
			'sull\'asse X, e una colonna con i valori da conteggiare, che verr&agrave; rappresentata sull\'asse Y. Questa seconda colonna potr&agrave; avere dei valori da sommare, o ' +
			' anche semplicemente delle occorrenze non sommabili da conteggiare',
	help_datasource_example_basicDatasetDiscretebarChart: '<p>Nell\'esempio dell\'immagine, il dataset analizzato aveva una serie di righe con \
								conteggi arrivi turistici, per provincia, anno e settore, nel grafico si &egrave; scelto raggruppare per provincia</p>\
	<table class="table help-widget-table-example"><thead><tr><th>Anno</th><th>Provincia</th><th>Settore</th><th>Arrivi Totali</th></tr></thead>\
	<tbody><tr><td>2008</td><td>BI</td><td>SETTORE EXTRALBERGHIERO</td><td>642</td></tr>\
	       <tr><td>2014</td><td>NO</td><td>SETTORE EXTRALBERGHIERO</td><td>670</td></tr>\
		   <tr><td>2018</td><td>CN</td><td>SETTORE EXTRALBERGHIERO</td><td>506</td></tr>\
		</tbody></table>',
//		   <tr><td>2005</td><td>AT</td><td>SETTORE EXTRALBERGHIERO</td><td>8004</td></tr>\
//		   <tr><td>2008</td><td>TO</td><td>SETTORE ALBERGHIERO</td><td>1000466</td></tr>\
//		   <tr><td>2014</td><td>CN</td><td>SETTORE EXTRALBERGHIERO</td><td>9422</td></tr>\
	help_listen_events_basicDatasetDiscretebarChart: '<ul><li>Cambio colonna su cui raggruppare</li><li>Cambio colonna su cui contare</li><li>Cambio criteri di filtro oData</li></ul>',
	help_sent_events_basicDatasetDiscretebarChart: '<ul><li>Evidenziazione di una barra del diagramma</li></ul>',
	help_related_widget_basicDatasetDiscretebarChart: '<ul><li>Tabella distribuzioni</li><li>Data explorer</li></ul>',
		
	/* Pie Chart */	
	basicDatasetPieChart: 'Grafico a torta/ciambella', 
	
	help_intro_basicDatasetPieChart: 'Con questo widget si rappresenta la distribuzione in classi di un carattere continuo',
	help_datasource_basicDatasetPieChart: 'Il widget si aspetta un dataset che abbia una colonna su cui raggruppare i dati che sar&agrave; rappresentata' + 
			' dalle fette della torta di dimensione proporzionata ai valori presenti su una seconda colonna del dataset, che potranno essere sommati  o ' +
			' anche semplicemente conteggiaggiati (in caso di occorrenze non sommabili)',
	help_datasource_example_basicDatasetPieChart: '<p>Nell\'esempio dell\'immagine, il dataset analizzato aveva una serie di righe con \
								conteggi arrivi turistici, per provincia, anno e settore, nel grafico si &egrave; scelto raggruppare per provincia</p>\
	<table class="table help-widget-table-example"><thead><tr><th>Anno</th><th>Provincia</th><th>Settore</th><th>Arrivi Totali</th></tr></thead>\
	<tbody><tr><td>2008</td><td>BI</td><td>SETTORE EXTRALBERGHIERO</td><td>642</td></tr>\
	       <tr><td>2014</td><td>NO</td><td>SETTORE EXTRALBERGHIERO</td><td>670</td></tr>\
		   <tr><td>2018</td><td>CN</td><td>SETTORE EXTRALBERGHIERO</td><td>506</td></tr>\
		</tbody></table>',
	help_listen_events_basicDatasetPieChart: '<ul><li>Cambio colonna su cui raggruppare</li><li>Cambio colonna su cui contare</li><li>Cambio criteri di filtro oData</li></ul>',
	help_sent_events_basicDatasetPieChart: '<ul><li>Evidenziazione di una fetta di torta</li></ul>',
	help_related_widget_basicDatasetPieChart: '<ul><li>Tabella distribuzioni</li><li>Data explorer</li></ul>',
		
	/* linechart */
	basicDatasetLineChart: 'Grafico a linea',
	
	
	/* basicDatasetTreemapChart */
	basicDatasetTreemapChart: 'Treemap',
	
	
	/* distribution table */
	basicDistributionTable: 'Tabella distribuzioni',
	help_intro_basicDistributionTable: 'Con questo widget a tabella si rappresentano i dati calcolati per una distribuzione in classi di un carattere continuo',
	help_datasource_basicDistributionTable: 'Il widget si aspetta un dataset che abbia una colonna su cui raggruppare i dati che sar&agrave; la prima colonna ' + 
			'della tabella, e una colonna con i valori da conteggiare, sar&agrave; la seconda colonna della tabella. Questa seconda colonna potr&agrave; avere dei valori da sommare, o ' +
			' anche semplicemente delle occorrenze non sommabili da conteggiare',
	help_datasource_example_basicDistributionTable: '<p>Nell\'esempio dell\'immagine, il dataset analizzato aveva una serie di righe con \
								una voce di spesa, per provincia, anno e settore, nel grafico si &egrave; scelto raggruppare per provincia</p>\
	<table class="table help-widget-table-example"><thead><tr><th>Anno</th><th>Provincia</th><th>Settore</th><th>Spesa</th></tr></thead>\
	<tbody><tr><td>2008</td><td>BI</td><td>SETTORE EXTRALBERGHIERO</td><td>642</td></tr>\
	       <tr><td>2014</td><td>NO</td><td>SETTORE EXTRALBERGHIERO</td><td>670</td></tr>\
		   <tr><td>2018</td><td>CN</td><td>SETTORE EXTRALBERGHIERO</td><td>506</td></tr>\
		</tbody></table>',
//		   <tr><td>2005</td><td>AT</td><td>SETTORE EXTRALBERGHIERO</td><td>8004</td></tr>\
//		   <tr><td>2008</td><td>TO</td><td>SETTORE ALBERGHIERO</td><td>1000466</td></tr>\
//		   <tr><td>2014</td><td>CN</td><td>SETTORE EXTRALBERGHIERO</td><td>9422</td></tr>\
	help_listen_events_basicDistributionTable: '<ul><li>Cambio colonna su cui raggruppare</li><li>Cambio colonna su cui contare</li><li>Cambio criteri di filtro oData</li></ul>',
	help_sent_events_basicDistributionTable: '<ul><li><i>nessuno</i></li></ul>',
	help_related_widget_basicDistributionTable: '<ul><li>Grafico a barre</li><li>Grafico a torta</li><li>Data explorer</li></ul>',
	

	/* select control */
	basicControlSelect: 'Controllo selezione valori', 
	help_intro_basicControlSelect: 'Con questo widget di controllo &egrave; possibile modificare la colonne prese in esame da altri widget',
	help_datasource_basicControlSelect: '&Egrave; possible impostare una lista di colonne di un dataset fra cui l\'utente potr&agrave; sciegliere. Le colonne proposte potranno essere sia quelle su cui raggruppare i dati, sia quelle su cui conteggiare/sommare i valori.\
		Il widget non si connette alle api per i dati, quindi &egrave; necessario conoscere a priori la struttura del dataset di cui si vuole indicare la scelta di colonne',
	help_datasource_example_basicControlSelect: '<i>Il widget non analizza dati</i>',
	help_listen_events_basicControlSelect: '<i>nessuno</i>',
	help_sent_events_basicControlSelect: '<ul><li>Cambio colonna su cui raggruppare</li><li>Cambio colonna su cui contare</li></ul>',
	help_related_widget_basicControlSelect: '<ul><li>Grafico a barre</li><li>Grafico a torta</li><li>Tabella distribuzioni</li></ul>',

	
	
	/* Choroplet Map */
	basicGeoChoropletMap: 'Mappa Coropletica', 

	
	/* inline help */
	
	help_inline_tenantcode:'&Egrave; il codice dell\'area di lavoro di cui fa parte il dataset/stream',
	help_inline_datasetcode:'&Egrave; il codice del dataset',
	help_inline_value_column: '&Egrave; la colonna del dataset che contiene il valore da prendere in considerazione',
	help_inline_group_by_column:'&Egrave; la colonna del dataset su cui fare il raggruppamento',
	help_inline_widget_title: '&Egrave; il titolo del widget',
	help_inline_widget_subtitle: '&Egrave; il sottotitolo del widget',
	help_inline_widget_intro: '&Egrave; un testo descrittivo introduttivo',
	
	help_inline_main_chart_color: '&Egrave; il colore primario da usare nel widget, da cui vengono ricavati eventuali sfumature grafiche. Se si specificano i singoli colori (parametro successivo), questo colore viene ignorato',
	help_inline_chart_colors: 'Sono i colori da usare nel widget, se il numero di colori è minore alle categorie visualizzate, i colori si ripetono. Specificando questi colori, il colore principale (parametro precendente) viene ignorato',
	help_inline_chart_height: 'Altezza in pixel del wiget',
	help_inline_chart_width: 'Larghezza in pixel del widget',
	help_inline_show_values: 'Mostra i valori sul grafico',
	help_inline_chart_legend: 'Visibilit&agrave; e posizione nel widget della legenda',
	help_inline_x_axis: 'Visibilit&agrave; e etichetta da usare per l\'asse X',
	help_inline_y_axis: 'Visibilit&agrave; e etichetta da usare per l\'asse X',
	help_inline_grouped_query: 'Da usare se le colonne da conteggiare sono state metadatate come raggruppabili',
	help_inline_filter: '&Egrave; il filtro da usare per le chiamate oData',
	help_inline_skip: '&Egrave; numero di righe da cui partire nelle chiamate oData ',
	help_inline_top: '&Egrave; il limite massimo di righe nelle chiamate oData (se non impostato estrae massimo 10.000 righe)',
	help_inline_euro_value: 'Selezionare se il dato va formattato come Euro',
	help_inline_format_big_number: 'Formattazione dei numeri grossi con abbreviazioni<br><strong>Esempi</strong><br> 2400 &rarr; 2,4K <br>3200000 &rarr; 3,2M ',
	help_inline_decimal_value: 'Indicare il numero di cifre decimali da visualizzare',
	help_inline_usertoken: 'Token per la visualizzazione di dataset/stream privati.<br><i class="fa fa-warning"></i> <strong>Attenzione</strong> Il token impostato qui sar&agrave; visible sul codice sorgente della pagina contenente il widget. Utilizzare solo in caso di sviluppo, o se si tratta di dashboard private. In caso di dashboard pubbliche impostare il token nella componente server.',
	help_inline_debug: 'Visualizza eventuali messaggi di errore nel widget stesso, si consiglia di utilizzarlo solo nella fase di sviluppo',

	help_inline_evt_change_valuecolumn:'Evento di cambio della colonna valore, rilanciato da altri widget (grafici o di controllo)',
	help_inline_evt_change_groupbycolumn: 'Evento di cambio della colonna raggruppamento, rilanciato da altri widget (grafici o di controllo)',
	help_inline_evt_filtertext: 'Evento di cambio filtro della query odata con cui vengono recuperati i dati, rilanciato da altri widget di controllo',
	help_inline_evt_highlight_groupbycolumn: 'Evento di evidenziazione di un dato o di un elemento del grafico',
	
	help_style_css_selector: 'Selettore CSS',
	help_inline_yucca_widget_header_title:'Titolo del widget',
	help_inline_yucca_widget_header_subtitle:'Sottotitolo del widget',
	help_inline_yucca_widget_intro: 'Paragrafo introduttivo',
	help_inline_yucca_widget_footer: 'Pannello contenitore del footer',
	help_inline_yucca_widget_footer_text: 'Testo contenuto nel footer',
	
	help_inline_label_threshold: 'Percentuale di etichette da mostrare nel grafico', 

	
	widget_code_dialog_title: 'Codice del widget',
	
	/* styles */
	yucca_dataset_choropleth_map : 'Pannello principale',
	yucca_dataset_choropleth_map_header : 'Header',
	yucca_dataset_choropleth_map_content : 'Body',
	yucca_dataset_choropleth_map_map : 'Pannello mappa',
	yucca_dataset_choropleth_map_data : 'Pannello dati',
	yucca_dataset_choropleth_map_table : 'Tabella dati',
	yucca_dataset_choropleth_map_toolbar: 'Toolbar con men&ugrave per cambio pannello da visualizzare',
	
	
	/* composer */
	
	copy_to_clipboard_feedback_ok: 'Copiato negli appunti',
	components_section_dataset: 'Grafici per Dataset',
	components_section_geo: 'Mappe',
	components_section_table: 'Tabelle di dati',
	components_section_control: 'Controlli e Filtri',
	components_section_advanced: 'Widget avanzati',
	components_section_htmlelement: 'Elementi',
	
	widget_config_section_config: 'Configurazione',
	widget_config_section_event: 'Eventi',
	widget_config_section_style: 'Stile',
	
	render_select: 'Menù a tendina',
	render_radio: 'Radio Button',
	render_button: 'Tab Button',
	
	direction_rows: 'In riga',
	direction_columns: 'In colonna',
	
	optional: 'opzionale',
	params_section_mandatory:'Parametri',
	params_section_common:'Personalizzazioni',
	params_section_chart:'Personalizzazioni Grafico',
	params_section_odatafilter:'Filtri OData',
	params_section_number_format: 'Formato numeri',
	params_section_advanced: 'Parametri avanzati', 
	params_section_map: 'Personalizzazioni Mappa',
	param_tenantcode: 'Codice area di lavoro',
	param_datasetcode: 'Codice del dataset',
	param_value_column: 'Colonna con il valore',
	param_group_by_column: 'Colonna su cui raggruppare',
	
	param_widget_title: 'Titolo',
	param_widget_subtitle: 'Sottotitolo',
	param_widget_intro: 'Descrizione',
	param_main_chart_color: 'Colore principale',
	param_chart_colors: 'Colori da usare',
	param_chart_height: 'Altezza del widget',
	param_chart_width: 'Larghezza del widget',

	param_geojsons: 'Geojson da utilizzare', 
	param_range_colors: 'Colori da usare',
	param_zoom_control: 'Zoom sulla mappa',
	param_scroll_wheel_zoom: 'Zoom tramite rotella',
	param_map_legend: 'Legenda',
	
	
	param_show_values: 'Mostra valori',

	param_chart_legend: 'Legenda',
	param_x_axis: 'Asse X',
	param_y_axis: 'Asse Y',
	param_show_axis: 'Visibile',
	param_axis_label: 'Etichetta da visualizzare',
	
	param_euro_value: 'Valori in euro',
	param_decimal_value: 'Cifre decimali',
	param_format_big_number: 'Formattazione numeri grandi',
	
	param_usertoken: 'Usertoken',
	param_debug: 'Informazioni di debug',
	
	
	
	
	param_grouped_query:'Query con raggruppamenti',
	param_filter: 'Filtro OData',
	param_skip: 'Righe da saltare',
	param_top: 'Numero di righe',
	
	param_donut: 'Grafico a ciambella',
	param_label_threshold: 'Soglia visualizzazione etichette',

	
	param_value_columns: 'Colonne', 
	param_label: 'Etichetta',
	param_hint: 'Descrizione',
	param_selected_value: 'Valore inizialmente selezionato',
	param_select_empty_label: 'Etichetta quando non è selezionato nulla ',
	param_render: 'Tipo di visualizzazione',
	param_direction: 'Direzione',
	
	styles_section_common: 'Header e footer',
	styles_section_chart:'Area del grafico',
	styles_section_table:'Tabella dati',
	
	styles_section_common_basic_control: 'Titolo e introduzione',
	styles_section_basic_control_radio: 'Controllo di tipo radio',
	styles_section_basic_control_tabbutton: 'Controllo di tipo tab button',
	styles_section_basic_control_select: 'Controllo di tipo select',
	
	style_yucca_control_select_radio_panel: 'Pannello contenitore',
	style_yucca_control_select_radio_item: 'Elementi Radio',

	style_yucca_control_select_tabbutton_panel:  'Pannello contenitore',
	style_yucca_control_select_tabbutton_item: 'Elemento Tab',
	style_yucca_control_select_tabbutton_item_selected: 'Elemento Tab Selezionato',
	
	style_yucca_control_select_select_panel:  'Pannello contenitore',
	style_yucca_control_select_select: 'Menù a tendina		',

	style_yucca_widget_header_title: 'Titolo',
	style_yucca_widget_header_subtitle: 'Sottotitolo',
	style_yucca_widget_intro: 'introduzione',
	style_yucca_widget_footer: 'Footer',
	style_yucca_widget_footer_text: 'Testo nel footer',
	 
	style_yucca_widget_chart_content: 'Pannello contenente il grafico',
	style_yucca_widget_chart: 'Grafico',

	style_yucca_widget_table_content:'Pannello contenente la tabella',
	style_yucca_widget_table:'Tabella',
	style_yucca_widget_table_header_row:'Riga dell\'header', 	
	style_yucca_widget_table_header_cell:'Celle dell\'header',	
	style_yucca_widget_table_body_row:'Riga dei dati',
	style_yucca_widget_table_body_cell:'Cella dei dati',

	
	
	multiple_color_param_dialog_title: 'Inserimento di colori multipi',
	multiple_color_param_value: 'Colore',
	multiple_color_limit_param_value: 'per valori minori di ',
	multiple_keylabel_param_key: 'Colonna',
	multiple_keylabel_param_label: 'Etichetta',
	
	multiple_param_dialog_title: 'Inserimento di valori multipi',
	multiple_param_dialog_intro: 'Aggiungi dei valori per il parametro ',
	multiple_param_value: 'Valore',
	multiple_param_add: 'Aggiungi',
	multivalue_empty: 'Nessun valore',
	
	param_config_column_modal_title: 'Colonna',
	param_config_column_key: 'Nome',
	param_config_column_label: 'Etichetta',
	param_config_column_countingmode: 'Modalità conteggio',
	param_config_column_countingmode_hint: 'La modalit&agrave; di conteggio dipende dal tipo di query oData<ul><li>Query non raggruppate: <strong> count, sum</strong></li><li>Query raggruppate: <strong>sum, avg, min, max</strong></li></ul>',
	param_config_column_key_placeholder: 'Attributo name del componente',
	param_config_column_label_placeholder: 'Etichetta da visualizzare',
	
	
	
	param_geojsons_title: 'Geojson da utilizzare',
	multiple_param_geojsons_dialog_intro: 'Il widget utilizza il formato Geojson per rappresentare le aree sulla mappa. \
		&Egrave; possibile indicare le informazioni di uno o pi&ugrave; file geojson. ', 

	new_geojson: 'Nuovo Geojson',
	existing_geojson: 'Geojson configurati',
	geojson_url_param: 'Url',
	geojson_url_param_hint: 'Url dove &egrave; presente il file geojson', 
	geojson_key_param: 'Chiave',
	geojson_key_param_hint: 'Attributo inteno al file da mettere in relazione con la colonna del dataset da contare',
	geojson_render_line_param: 'Linea che separa le varie aree',
	geojson_render_line_weight_param: 'Spessore', 
	geojson_render_line_opacity_param: 'Opacit&agrave;', 
	geojson_render_line_dashcolor_param: 'Colore', 
	geojson_render_line_dasharray_param: 'Tratteggio', 
	geojson_render_areas_param: 'Aree',
	geojson_render_areas_fillopacity_param: 'Opacit&agrave;',
	
	/* piechart render */
	piechartrender_param_dialog_title: 'Personalizzazione grafico a torta',
	piechartrender_donut_title:'Grafico a ciambella',
	piechartrender_donut: 'Si',
	piechartrender_donutratio: 'Rapporto raggio (%)',
	piechartrender_piesection_title:'Sezione torta',
	piechartrender_fullpie: 'Completa',
	piechartrender_halfpie: 'Mezza',
	piechartrender_angles: 'Custom',
	piechartrender_angles_section:'Sezione',
	piechartrender_angles_rotation:'Rotazione',
	piechartrender_radius_title: 'Rotazione e spigoli',
	piechartrender_corner_radius: 'Arrotondamento', 
	
	
	
	events_section_event_listening: 'Eventi ascoltati dal widget',
	events_section_event_sending: 'Eventi rilanciati dal widget',
	
	event_evt_change_valuecolumn: 'Cambio colonna valore',
	event_evt_change_groupbycolumn: 'Cambio colonna raggruppamento',
	event_evt_filtertext: 'Filtro query oData',
	event_evt_highlight_groupbycolumn: 'Evidenziare colonna raggruppamento',
	
	event_enabled: 'Abilitato',
	event_only_same_dataaset: 'Solo stesso dataset',
	
	dashboard_save: 'Salva',
	dashboard_load: 'Apri',
	dashboard_embed: 'Incorpora',
	
	html_text: 'Testo',
	html_image: 'Immagine',

	legend_param_dialog_title:'Configurazione legenda',
	
	legend_position: 'Posizione della legenda',
	legend_param_preset_position_label: 'Posizioni predefinite', 
	legend_param_custom_position_label: 'Posizioni personalizzate', 
	
	help_datasource: 'Datasource necessario',
	help_datasource_example: 'Esempio di dati',
	help_listen_events: 'Eventi ascoltati',
	help_sent_events: 'Eventi rilanciati',
	help_related_widget: 'Altri widget strettamente correlati',

	
};
